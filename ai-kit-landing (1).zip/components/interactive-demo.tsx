"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Send, User, Bot, Sparkles } from "lucide-react"

interface Message {
  role: "user" | "assistant"
  content: string
}

export default function InteractiveDemo() {
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hola, soy Qwark. Puedes probar mi demo interactiva. ¿En qué puedo ayudarte hoy?",
    },
  ])
  const [isTyping, setIsTyping] = useState(false)

  const demoResponses: { [key: string]: string } = {
    default:
      "Gracias por tu mensaje. Como demo interactiva, mis respuestas son predefinidas, pero el Qwark real puede mantener conversaciones mucho más naturales y personalizadas.",
    hola: "¡Hola! ¿Cómo estás hoy? Estoy aquí para ayudarte con cualquier pregunta que tengas.",
    ayuda:
      "Puedo ayudarte con información, responder preguntas, generar ideas creativas, asistirte con código y mucho más. ¿Sobre qué tema necesitas ayuda?",
    qwark:
      "Soy Qwark, un asistente de IA diseñado para ser tu compañero digital. Aprendo de nuestras interacciones para ofrecerte respuestas más personalizadas y relevantes.",
    características:
      "Algunas de mis características incluyen: conversaciones naturales, respuestas precisas, personalización, asistencia con código, generación de ideas creativas y mucho más.",
    precio:
      "Ofrecemos varios planes: un plan gratuito con funciones básicas, un plan Premium por 9.99€/mes con funciones avanzadas, y un plan Pro por 19.99€/mes para profesionales y equipos.",
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    // Add user message
    const userMessage: Message = { role: "user", content: input }
    setMessages((prev) => [...prev, userMessage])
    setInput("")

    // Simulate AI typing
    setIsTyping(true)

    // Find appropriate response or use default
    const lowercaseInput = input.toLowerCase()
    let responseContent = demoResponses.default

    // Check for keywords in the input
    Object.keys(demoResponses).forEach((key) => {
      if (key !== "default" && lowercaseInput.includes(key)) {
        responseContent = demoResponses[key]
      }
    })

    // Simulate AI response after a delay
    setTimeout(() => {
      setIsTyping(false)
      const aiMessage: Message = { role: "assistant", content: responseContent }
      setMessages((prev) => [...prev, aiMessage])
    }, 1500)
  }

  return (
    <div className="max-w-3xl mx-auto bg-zinc-900/50 border border-white/10 rounded-xl overflow-hidden shadow-xl">
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
          </div>
          <span className="text-white text-sm font-medium">Demo interactiva</span>
          <div className="ml-2 px-1.5 py-0.5 bg-purple-600 rounded-md text-[10px] font-bold uppercase tracking-wider">
            Pruébame
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-purple-400" />
          <span className="text-xs text-gray-400">Respuestas simuladas</span>
        </div>
      </div>

      <div className="h-80 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-zinc-900 to-zinc-950">
        <AnimatePresence>
          {messages.map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex items-start gap-3 ${message.role === "user" ? "justify-end" : ""}`}
            >
              {message.role === "assistant" && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex-shrink-0 flex items-center justify-center">
                  <Bot size={16} className="text-white" />
                </div>
              )}
              <div
                className={`rounded-lg p-3 max-w-[80%] ${
                  message.role === "assistant"
                    ? "bg-zinc-800 border border-white/5"
                    : "bg-purple-600/20 border border-purple-500/20"
                }`}
              >
                <p className="text-white text-sm">{message.content}</p>
              </div>
              {message.role === "user" && (
                <div className="w-8 h-8 rounded-full bg-zinc-700 flex-shrink-0 flex items-center justify-center">
                  <User size={16} className="text-white" />
                </div>
              )}
            </motion.div>
          ))}

          {isTyping && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex-shrink-0 flex items-center justify-center">
                <Bot size={16} className="text-white" />
              </div>
              <div className="bg-zinc-800 rounded-lg p-3 border border-white/5">
                <div className="flex space-x-1">
                  <div
                    className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                    style={{ animationDelay: "0ms" }}
                  ></div>
                  <div
                    className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                    style={{ animationDelay: "150ms" }}
                  ></div>
                  <div
                    className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                    style={{ animationDelay: "300ms" }}
                  ></div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="p-4 border-t border-white/10">
        <form onSubmit={handleSubmit} className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Prueba preguntando sobre Qwark, sus características o precios..."
            className="w-full bg-zinc-800 border border-white/10 rounded-lg px-4 py-3 pr-12 text-white placeholder:text-gray-500
            focus:outline-none focus:ring-1 focus:ring-purple-600 focus:border-purple-600"
          />
          <button
            type="submit"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors p-2 rounded-md hover:bg-white/5"
            disabled={!input.trim()}
          >
            <Send size={18} />
          </button>
        </form>
        <p className="text-xs text-gray-500 mt-2 text-center">
          Esta es una demo con respuestas predefinidas. Prueba el Qwark real para una experiencia completa.
        </p>
      </div>
    </div>
  )
}
