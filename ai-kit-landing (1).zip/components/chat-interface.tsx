"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Send,
  User,
  Bot,
  Sparkles,
  Plus,
  Trash2,
  Download,
  Copy,
  Share2,
  ChevronLeft,
  ChevronRight,
  Settings,
  X,
  LogOut,
  Moon,
  Sun,
  Monitor,
  Bell,
  Volume2,
  Languages,
  Clock,
  Palette,
  Key,
  Shield,
  Square,
  ImageIcon,
  Paperclip,
  Mic,
  MoreHorizontal,
  Home,
  Star,
  Zap,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"
import { useTheme } from "@/contexts/theme-context"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface Chat {
  id: string
  title: string
  messages: Message[]
  createdAt: Date
  updatedAt: Date
}

interface ChatInterfaceProps {
  username: string
  onLogout: () => void
  onClose: () => void
  isGuest?: boolean
  guestMessageCount?: number
  maxGuestMessages?: number
}

export default function ChatInterface({
  username,
  onLogout,
  onClose,
  isGuest = false,
  guestMessageCount = 0,
  maxGuestMessages = 10,
}: ChatInterfaceProps) {
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [chats, setChats] = useState<Chat[]>([])
  const [activeChat, setActiveChat] = useState<string | null>(null)
  const [showNewChatButton, setShowNewChatButton] = useState(true)
  const [sidebarVisible, setSidebarVisible] = useState(true)
  const [showSettings, setShowSettings] = useState(false)
  const [activeSettingsTab, setActiveSettingsTab] = useState<"general" | "appearance" | "account" | "advanced">(
    "general",
  )
  const [notifications, setNotifications] = useState(true)
  const [sounds, setSounds] = useState(true)
  const [autoSave, setAutoSave] = useState(true)
  const [fontSize, setFontSize] = useState("medium")
  const [language, setLanguage] = useState("es")
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [selectedBackground, setSelectedBackground] = useState("neon-purple")
  const [remainingMessages, setRemainingMessages] = useState(maxGuestMessages - guestMessageCount)
  const [showWelcome, setShowWelcome] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const { theme, setTheme } = useTheme()

  // Backgrounds options - Mejorados con temas neón minimalistas
  const backgrounds = [
    {
      id: "neon-purple",
      name: "Neón Púrpura",
      color: "bg-black",
      accent: "from-purple-600 to-violet-800",
      border: "border-purple-700/30",
    },
    {
      id: "neon-blue",
      name: "Neón Azul",
      color: "bg-black",
      accent: "from-blue-600 to-indigo-800",
      border: "border-blue-700/30",
    },
    {
      id: "neon-green",
      name: "Neón Verde",
      color: "bg-black",
      accent: "from-emerald-500 to-teal-700",
      border: "border-emerald-700/30",
    },
    {
      id: "neon-pink",
      name: "Neón Rosa",
      color: "bg-black",
      accent: "from-pink-600 to-rose-700",
      border: "border-pink-700/30",
    },
    {
      id: "neon-gold",
      name: "Neón Dorado",
      color: "bg-black",
      accent: "from-amber-500 to-orange-700",
      border: "border-amber-700/30",
    },
  ]

  // Obtener el chat activo
  const currentChat = chats.find((chat) => chat.id === activeChat) || null

  // Crear un nuevo chat
  const createNewChat = () => {
    const newChatId = `chat_${Date.now()}`
    const newChat: Chat = {
      id: newChatId,
      title: "Nuevo chat",
      messages: [
        {
          id: `msg_${Date.now()}`,
          role: "assistant",
          content: `Hola ${username}, soy Qwark. ¿En qué puedo ayudarte hoy?`,
          timestamp: new Date(),
        },
      ],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    setChats((prevChats) => [newChat, ...prevChats])
    setActiveChat(newChatId)
    setShowNewChatButton(false)
    setShowWelcome(false)
  }

  // Eliminar un chat
  const deleteChat = (chatId: string) => {
    setChats((prevChats) => prevChats.filter((chat) => chat.id !== chatId))
    if (activeChat === chatId) {
      setActiveChat(null)
      setShowNewChatButton(true)
      setShowWelcome(true)
    }
  }

  // Eliminar todos los chats
  const deleteAllChats = () => {
    setChats([])
    setActiveChat(null)
    setShowNewChatButton(true)
    setShowWelcome(true)
    setConfirmDelete(false)
  }

  // Detener la respuesta de la IA
  const stopAIResponse = () => {
    setIsTyping(false)
  }

  // Enviar un mensaje
  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || !activeChat || isTyping) return

    // Verificar si el usuario invitado ha alcanzado el límite
    if (isGuest && remainingMessages <= 0) {
      // Mostrar mensaje de límite alcanzado
      const limitMessage: Message = {
        id: `msg_${Date.now()}`,
        role: "assistant",
        content:
          "Has alcanzado el límite de mensajes para usuarios no registrados. Por favor, crea una cuenta para continuar conversando con Qwark.",
        timestamp: new Date(),
      }

      setChats((prevChats) =>
        prevChats.map((chat) => {
          if (chat.id === activeChat) {
            return {
              ...chat,
              messages: [...chat.messages, limitMessage],
              updatedAt: new Date(),
            }
          }
          return chat
        }),
      )
      return
    }

    // Crear un nuevo mensaje del usuario
    const userMessage: Message = {
      id: `msg_${Date.now()}`,
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    // Actualizar el chat con el nuevo mensaje
    setChats((prevChats) =>
      prevChats.map((chat) => {
        if (chat.id === activeChat) {
          return {
            ...chat,
            messages: [...chat.messages, userMessage],
            title: chat.messages.length <= 1 ? input.slice(0, 30) : chat.title,
            updatedAt: new Date(),
          }
        }
        return chat
      }),
    )

    // Limpiar el input
    setInput("")

    // Restar un mensaje del límite para usuarios invitados
    if (isGuest) {
      setRemainingMessages((prev) => prev - 1)
    }

    // Simular respuesta inmediata de la IA (sin quedarse pensando)
    const aiResponses = [
      "Entiendo lo que me estás diciendo. ¿Puedes darme más detalles para ayudarte mejor?",
      "Gracias por compartir eso. Basado en lo que me dices, te recomendaría considerar estas opciones...",
      "Interesante punto de vista. Desde mi perspectiva, podría sugerirte que explores estas alternativas...",
      "He analizado tu consulta y creo que podría ayudarte con lo siguiente...",
      "Comprendo perfectamente. Permíteme ofrecerte algunas ideas que podrían serte útiles...",
    ]

    const randomResponse = aiResponses[Math.floor(Math.random() * aiResponses.length)]

    const aiResponse: Message = {
      id: `msg_${Date.now() + 1}`,
      role: "assistant",
      content: randomResponse,
      timestamp: new Date(),
    }

    // Pequeño retraso para que parezca natural pero sin quedarse "pensando"
    setTimeout(() => {
      setChats((prevChats) =>
        prevChats.map((chat) => {
          if (chat.id === activeChat) {
            return {
              ...chat,
              messages: [...chat.messages, aiResponse],
              updatedAt: new Date(),
            }
          }
          return chat
        }),
      )
    }, 500)
  }

  // Auto-scroll al último mensaje
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [currentChat?.messages, isTyping])

  // Auto-resize del textarea
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = "auto"
      inputRef.current.style.height = `${inputRef.current.scrollHeight}px`
    }
  }, [input])

  // Crear un chat inicial si no hay ninguno
  useEffect(() => {
    if (chats.length === 0 && !showNewChatButton) {
      createNewChat()
    }
  }, [chats.length, showNewChatButton])

  // Actualizar el contador de mensajes restantes
  useEffect(() => {
    if (isGuest) {
      setRemainingMessages(maxGuestMessages - guestMessageCount)
    }
  }, [isGuest, maxGuestMessages, guestMessageCount])

  // Formatear fecha
  const formatDate = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))

    if (days === 0) {
      return "Hoy"
    } else if (days === 1) {
      return "Ayer"
    } else if (days < 7) {
      return `Hace ${days} días`
    } else {
      return date.toLocaleDateString()
    }
  }

  // Obtener el fondo seleccionado
  const getSelectedBackground = () => {
    return backgrounds.find((bg) => bg.id === selectedBackground) || backgrounds[0]
  }

  // Obtener el color de acento según el fondo seleccionado
  const getAccentGradient = () => {
    const bg = getSelectedBackground()
    return `bg-gradient-to-r ${bg.accent}`
  }

  // Obtener el color de borde según el fondo seleccionado
  const getAccentBorder = () => {
    const bg = getSelectedBackground()
    return bg.border
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-black">
      {/* Elementos decorativos del fondo */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div
          className={`absolute top-1/4 left-1/4 w-64 h-64 ${getAccentGradient()} opacity-10 rounded-full blur-[100px]`}
        ></div>
        <div
          className={`absolute bottom-1/3 right-1/3 w-96 h-96 ${getAccentGradient()} opacity-10 rounded-full blur-[100px]`}
        ></div>
        <div
          className={`absolute top-2/3 right-1/4 w-48 h-48 ${getAccentGradient()} opacity-10 rounded-full blur-[100px]`}
        ></div>
      </div>

      {/* Barra superior fija */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-md border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
          {/* Logo a la izquierda */}
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2 group">
              <div
                className={`w-8 h-8 rounded-full ${getAccentGradient()} flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-md shadow-purple-500/20`}
              >
                <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
              </div>
              <span className="text-white text-base font-medium">Qwark</span>
              <div
                className={`ml-1 px-1.5 py-0.5 ${getAccentGradient()} rounded-md text-[10px] font-bold uppercase tracking-wider text-white shadow-sm`}
              >
                Beta
              </div>
            </Link>
          </div>

          {/* Navegación a la derecha */}
          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-md transition-colors text-sm shadow-sm"
            >
              <span className="flex items-center gap-1">
                <Home size={14} />
                Inicio
              </span>
            </Link>
            <Link
              href="/features"
              className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-md transition-colors text-sm shadow-sm"
            >
              <span className="flex items-center gap-1">
                <Star size={14} />
                Características
              </span>
            </Link>
            <div className="flex items-center gap-1 bg-zinc-900 rounded-md p-1 shadow-sm">
              <button
                onClick={() => setTheme("light")}
                className={`p-1.5 rounded-md ${theme === "light" ? "bg-zinc-800" : ""}`}
                aria-label="Tema claro"
              >
                <Sun size={14} className="text-white" />
              </button>
              <button
                onClick={() => setTheme("dark")}
                className={`p-1.5 rounded-md ${theme === "dark" ? "bg-zinc-800" : ""}`}
                aria-label="Tema oscuro"
              >
                <Moon size={14} className="text-white" />
              </button>
              <button
                onClick={() => setTheme("system")}
                className={`p-1.5 rounded-md ${theme === "system" ? "bg-zinc-800" : ""}`}
                aria-label="Tema del sistema"
              >
                <Monitor size={14} className="text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Sidebar Toggle Button */}
      <button
        onClick={() => setSidebarVisible(!sidebarVisible)}
        className="fixed top-20 left-1 z-30 bg-zinc-900 rounded-full p-1 text-white shadow-sm border border-zinc-800 opacity-70 hover:opacity-100 transition-opacity"
        aria-label={sidebarVisible ? "Ocultar chats" : "Mostrar chats"}
      >
        {sidebarVisible ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
      </button>

      {/* Sidebar - Rediseñada */}
      <AnimatePresence>
        {sidebarVisible && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 280, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="h-full border-r border-zinc-800 bg-black/90 backdrop-blur-md flex flex-col overflow-hidden mt-14 shadow-md"
          >
            {/* Sidebar Header */}
            <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
              <h2 className="text-sm font-medium text-white">Mis conversaciones</h2>
              <button
                onClick={createNewChat}
                className={`p-1.5 rounded-md bg-zinc-900 hover:bg-zinc-800 text-white transition-colors shadow-sm`}
                title="Nuevo chat"
              >
                <Plus size={16} />
              </button>
            </div>

            {/* Chat List */}
            <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-transparent">
              {showNewChatButton ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <button
                    onClick={createNewChat}
                    className={`flex items-center gap-2 px-4 py-2 ${getAccentGradient()} text-white rounded-md transition-colors shadow-md`}
                  >
                    <Plus size={16} />
                    <span>Nuevo chat</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-1">
                  {chats.map((chat) => (
                    <div
                      key={chat.id}
                      className={`flex items-center justify-between rounded-md px-3 py-2 cursor-pointer group ${
                        activeChat === chat.id
                          ? `bg-zinc-900 text-white shadow-sm ${getAccentBorder()}`
                          : "text-zinc-400 hover:bg-zinc-900/50"
                      }`}
                      onClick={() => setActiveChat(chat.id)}
                    >
                      <div className="flex items-center gap-2 overflow-hidden">
                        <div
                          className={`w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center ${
                            activeChat === chat.id ? getAccentGradient() : "bg-zinc-800"
                          }`}
                        >
                          <Bot size={14} className="text-white" />
                        </div>
                        <div className="truncate">
                          <div className="text-sm truncate font-medium">{chat.title}</div>
                          <div className="text-xs text-zinc-500">{formatDate(chat.updatedAt)}</div>
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          deleteChat(chat.id)
                        }}
                        className="opacity-0 group-hover:opacity-100 text-zinc-500 hover:text-red-500 transition-opacity"
                        title="Eliminar chat"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Sidebar Footer with Settings Panel */}
            <div className="border-t border-zinc-800">
              {/* Settings Panel (Integrated in sidebar) */}
              <AnimatePresence>
                {showSettings && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden bg-zinc-900/50 backdrop-blur-sm"
                  >
                    <div className="p-3 border-b border-zinc-800 flex justify-between items-center">
                      <h3 className="text-sm font-medium text-white">Ajustes</h3>
                      <button onClick={() => setShowSettings(false)} className="text-zinc-500 hover:text-white">
                        <X size={16} />
                      </button>
                    </div>

                    <div className="flex border-b border-zinc-800">
                      <button
                        onClick={() => setActiveSettingsTab("general")}
                        className={`flex-1 py-2 text-xs font-medium ${
                          activeSettingsTab === "general"
                            ? "text-white border-b-2 border-purple-600"
                            : "text-zinc-500 hover:text-white"
                        }`}
                      >
                        General
                      </button>
                      <button
                        onClick={() => setActiveSettingsTab("appearance")}
                        className={`flex-1 py-2 text-xs font-medium ${
                          activeSettingsTab === "appearance"
                            ? "text-white border-b-2 border-purple-600"
                            : "text-zinc-500 hover:text-white"
                        }`}
                      >
                        Apariencia
                      </button>
                      <button
                        onClick={() => setActiveSettingsTab("account")}
                        className={`flex-1 py-2 text-xs font-medium ${
                          activeSettingsTab === "account"
                            ? "text-white border-b-2 border-purple-600"
                            : "text-zinc-500 hover:text-white"
                        }`}
                      >
                        Cuenta
                      </button>
                    </div>

                    <div className="p-3 max-h-[calc(100vh-20rem)] overflow-y-auto scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-transparent">
                      {activeSettingsTab === "general" && (
                        <div className="space-y-3">
                          <div>
                            <h4 className="text-xs font-medium text-white mb-2">Notificaciones</h4>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between rounded-md hover:bg-zinc-800 p-2">
                                <div className="flex items-center gap-2">
                                  <Bell size={14} className="text-zinc-400" />
                                  <span className="text-xs text-white">Notificaciones</span>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={notifications}
                                    onChange={() => setNotifications(!notifications)}
                                    className="sr-only peer"
                                  />
                                  <div className="w-9 h-5 bg-zinc-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-600 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-600 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                                </label>
                              </div>

                              <div className="flex items-center justify-between rounded-md hover:bg-zinc-800 p-2">
                                <div className="flex items-center gap-2">
                                  <Volume2 size={14} className="text-zinc-400" />
                                  <span className="text-xs text-white">Sonidos</span>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={sounds}
                                    onChange={() => setSounds(!sounds)}
                                    className="sr-only peer"
                                  />
                                  <div className="w-9 h-5 bg-zinc-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-600 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-600 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                                </label>
                              </div>
                            </div>
                          </div>

                          <div>
                            <h4 className="text-xs font-medium text-white mb-2">Idioma</h4>
                            <div className="flex items-center justify-between rounded-md hover:bg-zinc-800 p-2">
                              <div className="flex items-center gap-2">
                                <Languages size={14} className="text-zinc-400" />
                                <span className="text-xs text-white">Idioma</span>
                              </div>
                              <select
                                value={language}
                                onChange={(e) => setLanguage(e.target.value)}
                                className="text-xs bg-zinc-800 border border-zinc-700 rounded p-1 text-white"
                              >
                                <option value="es">Español</option>
                                <option value="en">English</option>
                                <option value="fr">Français</option>
                              </select>
                            </div>
                          </div>

                          <div>
                            <h4 className="text-xs font-medium text-white mb-2">Guardado</h4>
                            <div className="flex items-center justify-between rounded-md hover:bg-zinc-800 p-2">
                              <div className="flex items-center gap-2">
                                <Clock size={14} className="text-zinc-400" />
                                <span className="text-xs text-white">Autoguardado</span>
                              </div>
                              <label className="relative inline-flex items-center cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={autoSave}
                                  onChange={() => setAutoSave(!autoSave)}
                                  className="sr-only peer"
                                />
                                <div className="w-9 h-5 bg-zinc-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-600 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-600 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600"></div>
                              </label>
                            </div>
                          </div>
                        </div>
                      )}

                      {activeSettingsTab === "appearance" && (
                        <div className="space-y-3">
                          <div>
                            <h4 className="text-xs font-medium text-white mb-2">Tema</h4>
                            <div className="grid grid-cols-3 gap-2">
                              <button
                                onClick={() => setTheme("light")}
                                className={`flex flex-col items-center gap-1 p-2 rounded-md ${
                                  theme === "light"
                                    ? "bg-zinc-800 border border-purple-600"
                                    : "bg-zinc-900 border border-zinc-800"
                                }`}
                              >
                                <Sun size={14} className="text-white" />
                                <span className="text-xs text-white">Claro</span>
                              </button>
                              <button
                                onClick={() => setTheme("dark")}
                                className={`flex flex-col items-center gap-1 p-2 rounded-md ${
                                  theme === "dark"
                                    ? "bg-zinc-800 border border-purple-600"
                                    : "bg-zinc-900 border border-zinc-800"
                                }`}
                              >
                                <Moon size={14} className="text-white" />
                                <span className="text-xs text-white">Oscuro</span>
                              </button>
                              <button
                                onClick={() => setTheme("system")}
                                className={`flex flex-col items-center gap-1 p-2 rounded-md ${
                                  theme === "system"
                                    ? "bg-zinc-800 border border-purple-600"
                                    : "bg-zinc-900 border border-zinc-800"
                                }`}
                              >
                                <Monitor size={14} className="text-white" />
                                <span className="text-xs text-white">Sistema</span>
                              </button>
                            </div>
                          </div>

                          <div>
                            <h4 className="text-xs font-medium text-white mb-2">Color de acento</h4>
                            <div className="grid grid-cols-3 gap-2">
                              {backgrounds.map((bg) => (
                                <button
                                  key={bg.id}
                                  onClick={() => setSelectedBackground(bg.id)}
                                  className={`flex flex-col items-center gap-1 p-2 rounded-md ${
                                    selectedBackground === bg.id
                                      ? "bg-zinc-800 border border-purple-600"
                                      : "bg-zinc-900 border border-zinc-800"
                                  }`}
                                >
                                  <div className={`w-6 h-6 rounded-full bg-gradient-to-r ${bg.accent} shadow-sm`}></div>
                                  <span className="text-xs text-white">{bg.name}</span>
                                </button>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h4 className="text-xs font-medium text-white mb-2">Texto</h4>
                            <div className="flex items-center justify-between rounded-md hover:bg-zinc-800 p-2">
                              <div className="flex items-center gap-2">
                                <Palette size={14} className="text-zinc-400" />
                                <span className="text-xs text-white">Tamaño</span>
                              </div>
                              <select
                                value={fontSize}
                                onChange={(e) => setFontSize(e.target.value)}
                                className="text-xs bg-zinc-800 border border-zinc-700 rounded p-1 text-white"
                              >
                                <option value="small">Pequeño</option>
                                <option value="medium">Mediano</option>
                                <option value="large">Grande</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      )}

                      {activeSettingsTab === "account" && (
                        <div className="space-y-3">
                          <div className="p-2 bg-zinc-800 rounded-lg">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-8 h-8 rounded-full ${getAccentGradient()} flex items-center justify-center shadow-sm`}
                              >
                                <User size={16} className="text-white" />
                              </div>
                              <div>
                                <p className="text-xs font-medium text-white">{username}</p>
                                <p className="text-xs text-zinc-500">Usuario</p>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <button className="w-full flex items-center gap-2 p-2 text-left rounded-md hover:bg-zinc-800 transition-colors">
                              <User size={14} className="text-zinc-400" />
                              <span className="text-xs text-white">Editar perfil</span>
                            </button>
                            <button className="w-full flex items-center gap-2 p-2 text-left rounded-md hover:bg-zinc-800 transition-colors">
                              <Key size={14} className="text-zinc-400" />
                              <span className="text-xs text-white">Cambiar contraseña</span>
                            </button>
                            <button className="w-full flex items-center gap-2 p-2 text-left rounded-md hover:bg-zinc-800 transition-colors">
                              <Shield size={14} className="text-zinc-400" />
                              <span className="text-xs text-white">Privacidad</span>
                            </button>
                          </div>

                          <div className="pt-2 border-t border-zinc-800">
                            <button
                              onClick={() => (confirmDelete ? deleteAllChats() : setConfirmDelete(true))}
                              className={`w-full flex items-center gap-2 p-2 text-left rounded-md ${
                                confirmDelete ? "bg-red-900/20 text-red-400" : "hover:bg-zinc-800 text-white"
                              } transition-colors`}
                            >
                              <Trash2 size={14} className={confirmDelete ? "text-red-400" : "text-zinc-400"} />
                              <span className="text-xs">
                                {confirmDelete
                                  ? "¿Estás seguro? Haz clic de nuevo para confirmar"
                                  : "Eliminar todos los chats"}
                              </span>
                            </button>

                            <button
                              onClick={onLogout}
                              className="w-full flex items-center gap-2 p-2 text-left rounded-md text-red-400 hover:bg-red-900/20 transition-colors mt-2"
                            >
                              <LogOut size={14} />
                              <span className="text-xs font-medium">Cerrar sesión</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* User info and settings toggle */}
              <div className="p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-full ${getAccentGradient()} flex items-center justify-center shadow-sm`}
                  >
                    <User size={14} className="text-white" />
                  </div>
                  <span className="text-sm text-white font-medium truncate">{username}</span>
                </div>
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className={`p-1.5 rounded-md ${
                    showSettings
                      ? "bg-zinc-800 text-white shadow-inner"
                      : "bg-zinc-900 hover:bg-zinc-800 text-white shadow-sm"
                  }`}
                  title="Ajustes"
                >
                  <Settings size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col mt-14">
        {/* Chat Header */}
        <div className="bg-black/90 backdrop-blur-md border-b border-zinc-800 p-4 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2">
            {currentChat && (
              <>
                <div
                  className={`w-6 h-6 rounded-full ${getAccentGradient()} flex items-center justify-center shadow-sm`}
                >
                  <Sparkles size={14} className="text-white" />
                </div>
                <span className="text-white text-sm font-medium">{currentChat.title}</span>
              </>
            )}
          </div>
          <div className="flex items-center gap-3">
            <button className="text-zinc-400 hover:text-white transition-colors" onClick={onClose} title="Cerrar chat">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Chat Messages - Rediseñado */}
        {currentChat ? (
          <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-black bg-opacity-100 bg-fixed bg-center scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-transparent">
            <AnimatePresence initial={false}>
              {currentChat.messages.map((msg, index) => (
                <motion.div
                  key={msg.id}
                  className={`flex items-start gap-3 ${msg.role === "user" ? "justify-end" : ""} relative z-10`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {msg.role === "assistant" && (
                    <div
                      className={`w-8 h-8 rounded-full ${getAccentGradient()} flex-shrink-0 flex items-center justify-center mt-1 shadow-lg`}
                    >
                      <Bot size={16} className="text-white" />
                    </div>
                  )}
                  <div
                    className={`group relative rounded-lg p-3 max-w-[85%] ${
                      msg.role === "assistant"
                        ? "bg-zinc-900 border border-zinc-800 shadow-lg"
                        : `${getAccentGradient()} text-white shadow-md`
                    }`}
                  >
                    <p
                      className={`${msg.role === "assistant" ? "text-white" : "text-white"} whitespace-pre-wrap ${
                        fontSize === "small" ? "text-xs" : fontSize === "large" ? "text-base" : "text-sm"
                      }`}
                    >
                      {msg.content}
                    </p>

                    {/* Message actions - Rediseñado */}
                    <div className="absolute -top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                      <button
                        className="p-1 rounded-md bg-zinc-800 text-zinc-400 hover:text-white shadow-sm border border-zinc-700"
                        title="Copiar mensaje"
                        onClick={() => {
                          navigator.clipboard.writeText(msg.content)
                        }}
                      >
                        <Copy size={14} />
                      </button>
                      {msg.role === "assistant" && (
                        <>
                          <button
                            className="p-1 rounded-md bg-zinc-800 text-zinc-400 hover:text-white shadow-sm border border-zinc-700"
                            title="Compartir"
                          >
                            <Share2 size={14} />
                          </button>
                          <button
                            className="p-1 rounded-md bg-zinc-800 text-zinc-400 hover:text-white shadow-sm border border-zinc-700"
                            title="Descargar"
                          >
                            <Download size={14} />
                          </button>
                        </>
                      )}
                    </div>

                    <div className="mt-1 text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="text-zinc-500">
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                  {msg.role === "user" && (
                    <div className="w-8 h-8 rounded-full bg-zinc-800 flex-shrink-0 flex items-center justify-center mt-1 shadow-md">
                      <User size={16} className="text-white" />
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>

            {isTyping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-start gap-3 relative z-10"
              >
                <div
                  className={`w-8 h-8 rounded-full ${getAccentGradient()} flex-shrink-0 flex items-center justify-center mt-1 shadow-lg`}
                >
                  <Bot size={16} className="text-white" />
                </div>
                <div className="bg-zinc-900 rounded-lg p-3 border border-zinc-800 shadow-lg">
                  <div className="flex space-x-1">
                    <div
                      className="w-2 h-2 rounded-full bg-purple-400 animate-bounce"
                      style={{ animationDelay: "0ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-purple-400 animate-bounce"
                      style={{ animationDelay: "150ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-purple-400 animate-bounce"
                      style={{ animationDelay: "300ms" }}
                    ></div>
                  </div>
                </div>
                <button
                  onClick={stopAIResponse}
                  className="p-1.5 rounded-md bg-red-900/20 hover:bg-red-900/30 text-red-400 transition-colors shadow-md"
                  title="Detener respuesta"
                >
                  <Square size={14} />
                </button>
              </motion.div>
            )}

            <div ref={messagesEndRef} />
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-black">
            {/* Pantalla de bienvenida */}
            {showWelcome ? (
              <div className="text-center max-w-2xl p-6 relative z-10">
                <div
                  className={`w-20 h-20 rounded-full ${getAccentGradient()} flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/20`}
                >
                  <Sparkles size={32} className="text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Bienvenido a Qwark</h3>
                <p className="text-zinc-300 mb-8 text-lg">
                  Tu asistente de IA personal e intuitivo. Estoy aquí para ayudarte con lo que necesites.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                  <div className="bg-zinc-900 rounded-xl p-4 shadow-md border border-zinc-800 text-left">
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className={`w-8 h-8 rounded-full ${getAccentGradient()} flex items-center justify-center shadow-sm`}
                      >
                        <Zap size={16} className="text-white" />
                      </div>
                      <h4 className="text-sm font-semibold text-white">Respuestas precisas</h4>
                    </div>
                    <p className="text-xs text-zinc-400">
                      Obtén información relevante y actualizada para todas tus preguntas.
                    </p>
                  </div>

                  <div className="bg-zinc-900 rounded-xl p-4 shadow-md border border-zinc-800 text-left">
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className={`w-8 h-8 rounded-full ${getAccentGradient()} flex items-center justify-center shadow-sm`}
                      >
                        <MessageSquare size={16} className="text-white" />
                      </div>
                      <h4 className="text-sm font-semibold text-white">Conversaciones naturales</h4>
                    </div>
                    <p className="text-xs text-zinc-400">
                      Habla conmigo como lo harías con un amigo. Entiendo el contexto y mantengo conversaciones fluidas.
                    </p>
                  </div>
                </div>

                <button
                  onClick={createNewChat}
                  className={`px-6 py-3 ${getAccentGradient()} text-white rounded-md transition-colors shadow-lg shadow-purple-500/20 transform hover:scale-[1.02] duration-200`}
                >
                  <span className="flex items-center gap-2">
                    Comenzar a chatear <Sparkles size={16} />
                  </span>
                </button>
              </div>
            ) : (
              <div className="text-center max-w-md p-6 relative z-10">
                <div
                  className={`w-16 h-16 rounded-full ${getAccentGradient()} flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-500/20`}
                >
                  <Sparkles size={24} className="text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Comienza una nueva conversación</h3>
                <p className="text-zinc-400 mb-6">
                  Haz clic en el botón "Nuevo chat" para comenzar a hablar con Qwark.
                </p>
                <button
                  onClick={createNewChat}
                  className={`px-4 py-2 ${getAccentGradient()} text-white rounded-md transition-colors shadow-lg shadow-purple-500/20`}
                >
                  <span className="flex items-center gap-2">
                    Nuevo chat <Plus size={16} />
                  </span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Chat Input - Rediseñado */}
        {currentChat && (
          <div className="border-t border-zinc-800 p-4 bg-black/90 backdrop-blur-md">
            <form onSubmit={sendMessage} className="relative">
              <div className="flex items-center gap-2 mb-2">
                <button
                  type="button"
                  className="p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white transition-colors shadow-sm"
                  title="Adjuntar archivo"
                >
                  <Paperclip size={16} />
                </button>
                <button
                  type="button"
                  className="p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white transition-colors shadow-sm"
                  title="Adjuntar imagen"
                >
                  <ImageIcon size={16} />
                </button>
                <button
                  type="button"
                  className="p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white transition-colors shadow-sm"
                  title="Usar micrófono"
                >
                  <Mic size={16} />
                </button>
                <button
                  type="button"
                  className="p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white transition-colors shadow-sm"
                  title="Más opciones"
                >
                  <MoreHorizontal size={16} />
                </button>
              </div>

              <div className="relative rounded-xl overflow-hidden shadow-md">
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      sendMessage(e)
                    }
                  }}
                  placeholder={isTyping ? "Espera a que Qwark termine de responder..." : "Envía un mensaje..."}
                  className={`w-full bg-zinc-900 border-0 rounded-xl px-4 py-3 pr-12 text-white placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent transition-all duration-200 resize-none min-h-[44px] max-h-32 ${
                    isTyping ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                  rows={1}
                  disabled={isTyping}
                />
                {isTyping ? (
                  <button
                    type="button"
                    onClick={stopAIResponse}
                    className="absolute right-2 bottom-2 text-red-400 hover:text-red-300 transition-all p-2 rounded-md hover:bg-red-900/20"
                  >
                    <Square size={18} />
                  </button>
                ) : (
                  <button
                    type="submit"
                    className={`absolute right-2 bottom-2 text-white ${getAccentGradient()} transition-all p-2 rounded-md disabled:opacity-50 disabled:bg-zinc-700`}
                    disabled={!input.trim() || (isGuest && remainingMessages <= 0)}
                  >
                    <Send size={18} />
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between mt-2">
                <p className="text-xs text-zinc-500">Presiona Enter para enviar, Shift+Enter para nueva línea</p>
                {isGuest ? (
                  <p className="text-xs text-purple-400 font-medium">{remainingMessages} mensajes restantes</p>
                ) : (
                  <p className="text-xs text-zinc-500">
                    Versión Beta. Qwark está en desarrollo y puede cometer errores.
                  </p>
                )}
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  )
}
