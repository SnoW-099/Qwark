"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Settings,
  X,
  Volume2,
  Bell,
  User,
  Key,
  Shield,
  LogOut,
  Trash2,
  Download,
  MessageSquare,
  Palette,
  Clock,
  Languages,
  Sparkles,
  Zap,
  HelpCircle,
} from "lucide-react"
import { useTheme } from "@/contexts/theme-context"

interface SettingsPanelProps {
  onLogout: () => void
  onDeleteAllChats: () => void
  username: string
}

export default function SettingsPanel({ onLogout, onDeleteAllChats, username }: SettingsPanelProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<"general" | "account" | "appearance" | "advanced">("general")
  const [notifications, setNotifications] = useState(true)
  const [sounds, setSounds] = useState(true)
  const [autoSave, setAutoSave] = useState(true)
  const [language, setLanguage] = useState("es")
  const [fontSize, setFontSize] = useState("medium")
  const [confirmDelete, setConfirmDelete] = useState(false)
  const { theme, setTheme } = useTheme()

  const toggleSettings = () => {
    setIsOpen(!isOpen)
    if (confirmDelete) setConfirmDelete(false)
  }

  const handleDeleteAllChats = () => {
    if (confirmDelete) {
      onDeleteAllChats()
      setConfirmDelete(false)
    } else {
      setConfirmDelete(true)
    }
  }

  const handleLogout = () => {
    setIsOpen(false)
    setTimeout(() => {
      onLogout()
    }, 300)
  }

  // Cerrar el panel con la tecla Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        setIsOpen(false)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isOpen])

  return (
    <div className="relative">
      <button
        onClick={toggleSettings}
        className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
        aria-label="Ajustes"
      >
        <Settings size={18} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 dark:bg-black/70 backdrop-blur-sm z-40"
              onClick={toggleSettings}
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 mt-2 w-80 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-white/10 rounded-lg shadow-xl z-50"
            >
              <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-white/10">
                <h3 className="text-gray-900 dark:text-white font-medium">Ajustes</h3>
                <button
                  onClick={toggleSettings}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="flex border-b border-gray-200 dark:border-white/10">
                <button
                  onClick={() => setActiveTab("general")}
                  className={`flex-1 py-2 text-sm font-medium ${
                    activeTab === "general"
                      ? "text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400"
                      : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                  }`}
                >
                  General
                </button>
                <button
                  onClick={() => setActiveTab("appearance")}
                  className={`flex-1 py-2 text-sm font-medium ${
                    activeTab === "appearance"
                      ? "text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400"
                      : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                  }`}
                >
                  Apariencia
                </button>
                <button
                  onClick={() => setActiveTab("account")}
                  className={`flex-1 py-2 text-sm font-medium ${
                    activeTab === "account"
                      ? "text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400"
                      : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                  }`}
                >
                  Cuenta
                </button>
                <button
                  onClick={() => setActiveTab("advanced")}
                  className={`flex-1 py-2 text-sm font-medium ${
                    activeTab === "advanced"
                      ? "text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400"
                      : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                  }`}
                >
                  Avanzado
                </button>
              </div>

              <div className="p-4 max-h-[calc(100vh-16rem)] overflow-y-auto">
                {activeTab === "general" && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Notificaciones</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <div className="flex items-center gap-3">
                            <Bell size={18} className="text-gray-500 dark:text-gray-400" />
                            <div>
                              <p className="text-sm text-gray-700 dark:text-gray-300">Notificaciones</p>
                              <p className="text-xs text-gray-500">Recibe alertas de nuevas funciones</p>
                            </div>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={notifications}
                              onChange={() => setNotifications(!notifications)}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-zinc-600 peer-checked:bg-purple-600"></div>
                          </label>
                        </div>

                        <div className="flex items-center justify-between p-2 rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <div className="flex items-center gap-3">
                            <Volume2 size={18} className="text-gray-500 dark:text-gray-400" />
                            <div>
                              <p className="text-sm text-gray-700 dark:text-gray-300">Sonidos</p>
                              <p className="text-xs text-gray-500">Sonidos al recibir mensajes</p>
                            </div>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={sounds}
                              onChange={() => setSounds(!sounds)}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-zinc-600 peer-checked:bg-purple-600"></div>
                          </label>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Idioma</h4>
                      <div className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                        <Languages size={18} className="text-gray-500 dark:text-gray-400" />
                        <div className="flex-1">
                          <p className="text-sm text-gray-700 dark:text-gray-300">Idioma de la interfaz</p>
                        </div>
                        <select
                          value={language}
                          onChange={(e) => setLanguage(e.target.value)}
                          className="bg-white dark:bg-zinc-800 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-gray-300 text-sm rounded-md focus:ring-purple-500 focus:border-purple-500 p-1"
                        >
                          <option value="es">Español</option>
                          <option value="en">English</option>
                          <option value="fr">Français</option>
                          <option value="de">Deutsch</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Guardado</h4>
                      <div className="flex items-center justify-between p-2 rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                        <div className="flex items-center gap-3">
                          <Clock size={18} className="text-gray-500 dark:text-gray-400" />
                          <div>
                            <p className="text-sm text-gray-700 dark:text-gray-300">Autoguardado</p>
                            <p className="text-xs text-gray-500">Guardar chats automáticamente</p>
                          </div>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={autoSave}
                            onChange={() => setAutoSave(!autoSave)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-zinc-600 peer-checked:bg-purple-600"></div>
                        </label>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Ayuda</h4>
                      <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                        <HelpCircle size={18} className="text-gray-500 dark:text-gray-400" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">Centro de ayuda</span>
                      </button>
                      <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                        <MessageSquare size={18} className="text-gray-500 dark:text-gray-400" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">Enviar feedback</span>
                      </button>
                    </div>
                  </div>
                )}

                {activeTab === "appearance" && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Tema</h4>
                      <div className="grid grid-cols-3 gap-2 p-2">
                        <button
                          onClick={() => setTheme("light")}
                          className={`flex flex-col items-center gap-2 p-3 rounded-md ${
                            theme === "light"
                              ? "bg-purple-100 dark:bg-purple-900/30 border-2 border-purple-500"
                              : "bg-gray-100 dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 hover:bg-gray-200 dark:hover:bg-zinc-700"
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-white border border-gray-300 flex items-center justify-center">
                            <div className="w-4 h-4 rounded-full bg-yellow-400"></div>
                          </div>
                          <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Claro</span>
                        </button>
                        <button
                          onClick={() => setTheme("dark")}
                          className={`flex flex-col items-center gap-2 p-3 rounded-md ${
                            theme === "dark"
                              ? "bg-purple-100 dark:bg-purple-900/30 border-2 border-purple-500"
                              : "bg-gray-100 dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 hover:bg-gray-200 dark:hover:bg-zinc-700"
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center">
                            <div className="w-4 h-4 rounded-full bg-zinc-700 border border-zinc-600"></div>
                          </div>
                          <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Oscuro</span>
                        </button>
                        <button
                          onClick={() => setTheme("system")}
                          className={`flex flex-col items-center gap-2 p-3 rounded-md ${
                            theme === "system"
                              ? "bg-purple-100 dark:bg-purple-900/30 border-2 border-purple-500"
                              : "bg-gray-100 dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 hover:bg-gray-200 dark:hover:bg-zinc-700"
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-white to-zinc-900 border border-gray-300 flex items-center justify-center">
                            <div className="w-4 h-4 rounded-full bg-gradient-to-r from-yellow-400 to-zinc-700"></div>
                          </div>
                          <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Sistema</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Tamaño de texto</h4>
                      <div className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                        <Palette size={18} className="text-gray-500 dark:text-gray-400" />
                        <div className="flex-1">
                          <p className="text-sm text-gray-700 dark:text-gray-300">Tamaño de fuente</p>
                        </div>
                        <select
                          value={fontSize}
                          onChange={(e) => setFontSize(e.target.value)}
                          className="bg-white dark:bg-zinc-800 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-gray-300 text-sm rounded-md focus:ring-purple-500 focus:border-purple-500 p-1"
                        >
                          <option value="small">Pequeño</option>
                          <option value="medium">Mediano</option>
                          <option value="large">Grande</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Personalización</h4>
                      <div className="space-y-2">
                        <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <Sparkles size={18} className="text-gray-500 dark:text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">Personalizar interfaz</span>
                        </button>
                        <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <Zap size={18} className="text-gray-500 dark:text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">Atajos de teclado</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "account" && (
                  <div className="space-y-4">
                    <div className="p-3 bg-gray-100 dark:bg-zinc-800 rounded-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                          <User size={20} className="text-purple-600 dark:text-purple-400" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900 dark:text-white">{username}</p>
                          <p className="text-xs text-gray-500">Usuario</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Cuenta</h4>
                      <div className="space-y-1">
                        <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <User size={18} className="text-gray-500 dark:text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">Editar perfil</span>
                        </button>
                        <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <Key size={18} className="text-gray-500 dark:text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">Cambiar contraseña</span>
                        </button>
                        <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <Shield size={18} className="text-gray-500 dark:text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">Privacidad</span>
                        </button>
                        <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <Download size={18} className="text-gray-500 dark:text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">Exportar datos</span>
                        </button>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-gray-200 dark:border-zinc-700">
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-3 p-2 text-left rounded-md text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                      >
                        <LogOut size={18} />
                        <span className="text-sm font-medium">Cerrar sesión</span>
                      </button>
                    </div>
                  </div>
                )}

                {activeTab === "advanced" && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Datos</h4>
                      <div className="space-y-2">
                        <button
                          onClick={handleDeleteAllChats}
                          className={`w-full flex items-center gap-3 p-2 text-left rounded-md ${
                            confirmDelete
                              ? "bg-red-100 dark:bg-red-900/20 text-red-600"
                              : "hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-gray-300"
                          } transition-colors`}
                        >
                          <Trash2
                            size={18}
                            className={confirmDelete ? "text-red-600" : "text-gray-500 dark:text-gray-400"}
                          />
                          <span className="text-sm">
                            {confirmDelete
                              ? "¿Estás seguro? Haz clic de nuevo para confirmar"
                              : "Eliminar todos los chats"}
                          </span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Rendimiento</h4>
                      <div className="space-y-2">
                        <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                          <Zap size={18} className="text-gray-500 dark:text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">Optimizar rendimiento</span>
                        </button>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-gray-200 dark:border-zinc-700">
                      <p className="text-xs text-gray-500">
                        Qwark Beta v0.9.2 - Más opciones de personalización próximamente
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
