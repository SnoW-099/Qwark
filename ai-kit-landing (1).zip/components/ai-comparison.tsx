"use client"

import { motion } from "framer-motion"
import { Check, X } from "lucide-react"

interface ComparisonFeature {
  name: string
  qwark: boolean
  chatgpt: boolean
  gemini: boolean
  claude: boolean
  description?: string
}

export default function AIComparison() {
  const features: ComparisonFeature[] = [
    {
      name: "Conversaciones naturales",
      qwark: true,
      chatgpt: true,
      gemini: true,
      claude: true,
    },
    {
      name: "Personalización profunda",
      qwark: true,
      chatgpt: false,
      gemini: false,
      claude: false,
      description: "Qwark aprende de tus interacciones y se adapta a tu estilo y preferencias",
    },
    {
      name: "Memoria contextual",
      qwark: true,
      chatgpt: true,
      gemini: true,
      claude: true,
    },
    {
      name: "Generación de imágenes",
      qwark: true,
      chatgpt: true,
      gemini: true,
      claude: false,
      description: "Disponible en planes premium",
    },
    {
      name: "Asistencia con código",
      qwark: true,
      chatgpt: true,
      gemini: true,
      claude: true,
    },
    {
      name: "Interfaz minimalista",
      qwark: true,
      chatgpt: false,
      gemini: false,
      claude: true,
    },
    {
      name: "Modo creativo avanzado",
      qwark: true,
      chatgpt: false,
      gemini: false,
      claude: false,
      description: "Herramientas específicas para potenciar la creatividad",
    },
    {
      name: "Privacidad mejorada",
      qwark: true,
      chatgpt: false,
      gemini: false,
      claude: true,
      description: "Control total sobre tus datos y conversaciones",
    },
    {
      name: "Aplicación de escritorio",
      qwark: true,
      chatgpt: false,
      gemini: false,
      claude: false,
      description: "Próximamente",
    },
  ]

  return (
    <div className="py-12">
      <h2 className="text-3xl font-bold text-center mb-8">
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
          Qwark vs. Otras IAs
        </span>
      </h2>

      <div className="max-w-5xl mx-auto overflow-x-auto">
        <div className="min-w-[768px]">
          <div className="grid grid-cols-5 gap-4 mb-4">
            <div className="col-span-1 font-medium text-white"></div>
            <div className="col-span-1 text-center">
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center mb-2">
                  <div className="w-2 h-2 rounded-full bg-white"></div>
                </div>
                <span className="font-medium text-white">Qwark</span>
              </div>
            </div>
            <div className="col-span-1 text-center">
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center mb-2">
                  <span className="text-white text-xs font-bold">GPT</span>
                </div>
                <span className="font-medium text-white">ChatGPT</span>
              </div>
            </div>
            <div className="col-span-1 text-center">
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center mb-2">
                  <span className="text-white text-xs font-bold">G</span>
                </div>
                <span className="font-medium text-white">Gemini</span>
              </div>
            </div>
            <div className="col-span-1 text-center">
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 rounded-full bg-orange-600 flex items-center justify-center mb-2">
                  <span className="text-white text-xs font-bold">C</span>
                </div>
                <span className="font-medium text-white">Claude</span>
              </div>
            </div>
          </div>

          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className={`grid grid-cols-5 gap-4 p-3 rounded-lg ${index % 2 === 0 ? "bg-white/5" : "bg-transparent"}`}
            >
              <div className="col-span-1 flex items-center">
                <div>
                  <p className="font-medium text-white">{feature.name}</p>
                  {feature.description && <p className="text-xs text-gray-400 mt-1">{feature.description}</p>}
                </div>
              </div>
              <div className="col-span-1 flex justify-center items-center">
                {feature.qwark ? (
                  <div className="w-8 h-8 rounded-full bg-purple-600/20 flex items-center justify-center">
                    <Check size={16} className="text-purple-500" />
                  </div>
                ) : (
                  <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center">
                    <X size={16} className="text-red-500" />
                  </div>
                )}
              </div>
              <div className="col-span-1 flex justify-center items-center">
                {feature.chatgpt ? (
                  <div className="w-8 h-8 rounded-full bg-green-600/20 flex items-center justify-center">
                    <Check size={16} className="text-green-500" />
                  </div>
                ) : (
                  <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center">
                    <X size={16} className="text-red-500" />
                  </div>
                )}
              </div>
              <div className="col-span-1 flex justify-center items-center">
                {feature.gemini ? (
                  <div className="w-8 h-8 rounded-full bg-blue-600/20 flex items-center justify-center">
                    <Check size={16} className="text-blue-500" />
                  </div>
                ) : (
                  <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center">
                    <X size={16} className="text-red-500" />
                  </div>
                )}
              </div>
              <div className="col-span-1 flex justify-center items-center">
                {feature.claude ? (
                  <div className="w-8 h-8 rounded-full bg-orange-600/20 flex items-center justify-center">
                    <Check size={16} className="text-orange-500" />
                  </div>
                ) : (
                  <div className="w-8 h-8 rounded-full bg-red-600/10 flex items-center justify-center">
                    <X size={16} className="text-red-500" />
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
