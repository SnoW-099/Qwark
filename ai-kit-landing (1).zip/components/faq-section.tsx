"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown } from "lucide-react"

interface FAQItem {
  question: string
  answer: string
}

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs: FAQItem[] = [
    {
      question: "¿Qué es Qwark y en qué se diferencia de otros asistentes de IA?",
      answer:
        "Qwark es un asistente de IA conversacional diseñado para ser más personal, intuitivo y adaptable a tus necesidades. A diferencia de otros asistentes, Qwark aprende de tus interacciones para ofrecerte respuestas más relevantes y personalizadas, con un enfoque en la privacidad y una experiencia de usuario fluida.",
    },
    {
      question: "¿Necesito crear una cuenta para usar Qwark?",
      answer:
        "Sí, para aprovechar al máximo las capacidades de Qwark, necesitas crear una cuenta. Esto nos permite personalizar tu experiencia, guardar tus preferencias y ofrecerte un servicio más adaptado a tus necesidades. El registro es rápido y sencillo.",
    },
    {
      question: "¿Qué puedo preguntarle a Qwark?",
      answer:
        "¡Casi cualquier cosa! Qwark puede ayudarte con información general, responder preguntas específicas, asistirte en tareas creativas, ofrecer recomendaciones, ayudarte con código y programación, y mucho más. Cuanto más interactúes con Qwark, mejor entenderá tus necesidades.",
    },
    {
      question: "¿Cómo protege Qwark mi privacidad?",
      answer:
        "La privacidad es una prioridad para nosotros. Qwark está diseñado con un enfoque en la protección de datos, utilizando encriptación de extremo a extremo para tus conversaciones. No compartimos tus datos con terceros y te damos control total sobre qué información quieres que Qwark recuerde y utilice para personalizar tu experiencia.",
    },
    {
      question: "¿Cuáles son las limitaciones actuales de Qwark?",
      answer:
        "Como cualquier IA, Qwark tiene algunas limitaciones. Actualmente, puede tener conocimientos limitados sobre eventos muy recientes, puede ocasionalmente proporcionar información inexacta, y algunas funciones avanzadas como la generación de imágenes y el análisis de video están en desarrollo y llegarán próximamente.",
    },
    {
      question: "¿Cómo puedo obtener soporte si tengo problemas con Qwark?",
      answer:
        "Ofrecemos soporte a través de nuestro formulario de contacto, correo electrónico de soporte, y para usuarios premium, soporte prioritario. También puedes consultar nuestra documentación y tutoriales en la sección de ayuda, o utilizar el formulario de feedback para reportar problemas específicos.",
    },
  ]

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-3xl font-bold text-center mb-8">
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
          Preguntas frecuentes
        </span>
      </h2>

      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="border border-white/10 dark:border-white/5 rounded-lg overflow-hidden bg-zinc-900/50 dark:bg-zinc-900/30"
          >
            <button onClick={() => toggleFAQ(index)} className="flex justify-between items-center w-full p-4 text-left">
              <span className="font-medium text-white">{faq.question}</span>
              <motion.div animate={{ rotate: openIndex === index ? 180 : 0 }} transition={{ duration: 0.3 }}>
                <ChevronDown className="text-gray-400" size={20} />
              </motion.div>
            </button>

            <AnimatePresence>
              {openIndex === index && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="p-4 pt-0 text-gray-400 border-t border-white/5">{faq.answer}</div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
