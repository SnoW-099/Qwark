"use client"

import { useTheme } from "@/contexts/theme-context"
import { Moon, Sun, Monitor } from "lucide-react"
import { motion } from "framer-motion"

export default function ThemeToggleButton() {
  const { theme, setTheme } = useTheme()

  return (
    <div className="flex items-center gap-1 bg-zinc-800/50 dark:bg-zinc-800 rounded-full p-1 border border-white/5">
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => setTheme("light")}
        className={`p-1.5 rounded-full ${
          theme === "light"
            ? "bg-gradient-to-r from-amber-400 to-orange-500 text-white"
            : "text-gray-400 hover:text-white"
        }`}
        aria-label="Tema claro"
      >
        <Sun size={16} />
      </motion.button>
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => setTheme("dark")}
        className={`p-1.5 rounded-full ${
          theme === "dark"
            ? "bg-gradient-to-r from-purple-600 to-purple-800 text-white"
            : "text-gray-400 hover:text-white"
        }`}
        aria-label="Tema oscuro"
      >
        <Moon size={16} />
      </motion.button>
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => setTheme("system")}
        className={`p-1.5 rounded-full ${
          theme === "system"
            ? "bg-gradient-to-r from-blue-500 to-blue-700 text-white"
            : "text-gray-400 hover:text-white"
        }`}
        aria-label="Tema del sistema"
      >
        <Monitor size={16} />
      </motion.button>
    </div>
  )
}
