"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { X } from "lucide-react"

interface LoginModalProps {
  isOpen: boolean
  onClose: () => void
  onLogin: (username: string, password: string) => void
}

export default function LoginModal({ isOpen, onClose, onLogin }: LoginModalProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [message, setMessage] = useState("")
  const [messageColor, setMessageColor] = useState("")
  const [buttonPosition, setButtonPosition] = useState("")
  const [buttonDisabled, setButtonDisabled] = useState(true)
  const [rememberMe, setRememberMe] = useState(false)

  const btnRef = useRef<HTMLButtonElement>(null)
  const btnContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Check if fields are filled
    const isEmpty = username === "" || password === ""
    setButtonDisabled(isEmpty)

    if (isEmpty) {
      setMessage("Por favor, completa todos los campos")
      setMessageColor("text-red-500")
    } else {
      setMessage("¡Genial! Ahora puedes continuar")
      setMessageColor("text-green-400")
      setButtonPosition("translate-x-0 translate-y-0") // Reset position
    }
  }, [username, password])

  const shiftButton = () => {
    if (username === "" || password === "") {
      const positions = ["translate-x-[-120%]", "translate-y-[-150%]", "translate-x-[120%]", "translate-y-[150%]"]
      const currentIndex = positions.indexOf(buttonPosition)
      const nextIndex = (currentIndex + 1) % positions.length
      setButtonPosition(positions[nextIndex] || positions[0])
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!buttonDisabled) {
      onLogin(username, password)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="relative w-full max-w-md">
        {/* User Icon */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center z-10">
          <div className="text-gray-400 text-4xl">
            <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
              />
            </svg>
          </div>
        </div>

        {/* Close Button */}
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white z-10">
          <X size={20} />
        </button>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="flex flex-col items-center bg-zinc-900/90 border border-white/10 rounded-3xl pt-16 pb-8 px-6 shadow-xl"
        >
          <h2 className="text-xl font-bold text-white mb-10 mt-2">INICIAR SESIÓN</h2>

          {message && <p className={`text-sm mb-4 ${messageColor}`}>{message}</p>}

          <div className="relative w-full mb-6">
            <input
              type="text"
              placeholder="Usuario"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-transparent border-b border-zinc-700 py-2 pr-8 text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
            />
            <div className="absolute right-2 bottom-2 text-zinc-500">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                />
              </svg>
            </div>
          </div>

          <div className="relative w-full mb-6">
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-transparent border-b border-zinc-700 py-2 pr-8 text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
            />
            <div className="absolute right-2 bottom-2 text-zinc-500">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </div>
          </div>

          <div className="flex justify-between w-full text-sm mb-8">
            <label className="flex items-center text-zinc-400 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="mr-2 accent-purple-600"
              />
              Recordarme
            </label>
            <a href="#" className="text-zinc-400 hover:text-purple-400 transition-colors">
              ¿Olvidaste tu contraseña?
            </a>
          </div>

          <div
            ref={btnContainerRef}
            className="relative w-full h-16 flex items-center justify-center"
            onMouseOver={shiftButton}
          >
            <button
              ref={btnRef}
              type="submit"
              disabled={buttonDisabled}
              onMouseOver={shiftButton}
              onTouchStart={shiftButton}
              className={`
                px-8 py-2 bg-gradient-to-r from-purple-600 to-purple-800 
                text-white font-semibold rounded-xl transition-all duration-300
                hover:shadow-purple-800/30 shadow-lg shadow-purple-900/20
                absolute transform ${buttonPosition} ${!buttonDisabled ? "translate-x-0 translate-y-0" : ""}
              `}
            >
              Iniciar sesión
            </button>
          </div>

          <p className="text-zinc-600 mt-6">
            ¿No tienes una cuenta?{" "}
            <a href="#" className="text-zinc-400 hover:text-purple-400 transition-colors">
              Regístrate
            </a>
          </p>
        </form>
      </div>
    </div>
  )
}
