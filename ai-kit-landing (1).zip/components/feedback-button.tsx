"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { MessageSquare, X, Send, ThumbsUp, ThumbsDown } from "lucide-react"

export default function FeedbackButton() {
  const [isOpen, setIsOpen] = useState(false)
  const [feedback, setFeedback] = useState("")
  const [rating, setRating] = useState<"positive" | "negative" | null>(null)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    // Aquí iría la lógica para enviar el feedback
    console.log({ rating, feedback })
    setSubmitted(true)
    setTimeout(() => {
      setIsOpen(false)
      // Resetear después de cerrar
      setTimeout(() => {
        setSubmitted(false)
        setFeedback("")
        setRating(null)
      }, 300)
    }, 2000)
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
        aria-label="Dar feedback"
      >
        <MessageSquare size={16} />
        <span className="text-sm">Feedback</span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
              onClick={() => !submitted && setIsOpen(false)}
            />

            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.9 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 bg-white dark:bg-zinc-900 rounded-lg shadow-xl z-50 overflow-hidden"
            >
              <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                <h3 className="font-medium text-gray-900 dark:text-white">Tu opinión nos importa</h3>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white"
                >
                  <X size={18} />
                </button>
              </div>

              <AnimatePresence mode="wait">
                {submitted ? (
                  <motion.div
                    key="thanks"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="p-6 text-center"
                  >
                    <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                      <ThumbsUp className="text-green-600 dark:text-green-400" size={24} />
                    </div>
                    <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                      ¡Gracias por tu feedback!
                    </h4>
                    <p className="text-gray-600 dark:text-gray-400">
                      Tu opinión nos ayuda a mejorar Qwark para todos los usuarios.
                    </p>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    onSubmit={handleSubmit}
                    className="p-4"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <div className="mb-4">
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        ¿Cómo calificarías tu experiencia?
                      </p>
                      <div className="flex gap-3">
                        <button
                          type="button"
                          onClick={() => setRating("positive")}
                          className={`flex-1 py-2 px-3 rounded-md border ${
                            rating === "positive"
                              ? "border-green-500 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400"
                              : "border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600"
                          }`}
                        >
                          <ThumbsUp
                            size={18}
                            className={rating === "positive" ? "text-green-600 dark:text-green-400" : ""}
                          />
                        </button>
                        <button
                          type="button"
                          onClick={() => setRating("negative")}
                          className={`flex-1 py-2 px-3 rounded-md border ${
                            rating === "negative"
                              ? "border-red-500 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400"
                              : "border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600"
                          }`}
                        >
                          <ThumbsDown
                            size={18}
                            className={rating === "negative" ? "text-red-600 dark:text-red-400" : ""}
                          />
                        </button>
                      </div>
                    </div>

                    <div className="mb-4">
                      <label
                        htmlFor="feedback"
                        className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                      >
                        Cuéntanos más (opcional)
                      </label>
                      <textarea
                        id="feedback"
                        rows={3}
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        placeholder="¿Qué podemos mejorar?"
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md bg-white dark:bg-zinc-800 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      ></textarea>
                    </div>

                    <button
                      type="submit"
                      disabled={!rating}
                      className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white rounded-md py-2 px-4 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Send size={16} />
                      Enviar feedback
                    </button>
                  </motion.form>
                )}
              </AnimatePresence>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
