"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

interface LoadingScreenProps {
  onLoadingComplete: () => void
}

export default function LoadingScreen({ onLoadingComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const timer = setTimeout(() => {
      if (progress < 100) {
        setProgress((prev) => {
          const increment = Math.random() * 15
          const newProgress = Math.min(prev + increment, 100)
          return newProgress
        })
      } else {
        onLoadingComplete()
      }
    }, 200)

    return () => clearTimeout(timer)
  }, [progress, onLoadingComplete])

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute top-0 left-1/4 w-1/2 h-1/2 bg-purple-600/10 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "8s" }}
        ></div>
        <div
          className="absolute bottom-0 right-1/4 w-1/3 h-1/3 bg-purple-800/10 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "12s" }}
        ></div>
        <div
          className="absolute top-1/3 right-1/4 w-1/4 h-1/4 bg-purple-400/5 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "10s" }}
        ></div>
      </div>

      <div className="flex flex-col items-center">
        <motion.div
          className="w-32 h-32 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center mb-8"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        >
          <motion.div
            className="w-6 h-6 rounded-full bg-white"
            animate={{ scale: [1, 0.8, 1] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          ></motion.div>
        </motion.div>

        <h1 className="text-4xl font-bold text-white mb-4 flex items-center">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">Qwark</span>
          <div className="ml-3 px-2 py-1 bg-purple-600 rounded-md text-xs text-white font-bold uppercase tracking-wider animate-pulse">
            Beta
          </div>
        </h1>

        <div className="w-64 h-2 bg-zinc-800 rounded-full overflow-hidden mb-2">
          <motion.div
            className="h-full bg-gradient-to-r from-purple-500 to-purple-700"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        <p className="text-zinc-500 text-sm">{Math.round(progress)}% Cargando...</p>
      </div>
    </div>
  )
}
