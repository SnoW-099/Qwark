"use client"

import { useState } from "react"
import { Settings, X, Volume2, Bell, Moon, Sun, Monitor, User, Key, Shield } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export default function SettingsButton() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleSettings = () => {
    setIsOpen(!isOpen)
  }

  return (
    <div className="relative">
      <button
        onClick={toggleSettings}
        className="p-2 rounded-full bg-zinc-800 hover:bg-zinc-700 text-gray-300 hover:text-white transition-colors"
        aria-label="Ajustes"
      >
        <Settings size={18} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-40"
              onClick={toggleSettings}
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 mt-2 w-72 bg-zinc-900 border border-white/10 rounded-lg shadow-xl z-50"
            >
              <div className="flex items-center justify-between p-4 border-b border-white/10">
                <h3 className="text-white font-medium">Ajustes</h3>
                <button onClick={toggleSettings} className="text-gray-400 hover:text-white">
                  <X size={18} />
                </button>
              </div>

              <div className="p-4 space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-300 mb-2">Apariencia</h4>
                  <div className="flex items-center gap-3 p-2 rounded-md hover:bg-zinc-800 transition-colors">
                    <Moon size={18} className="text-gray-400" />
                    <div className="flex-1">
                      <p className="text-sm text-gray-300">Tema</p>
                    </div>
                    <div className="flex items-center gap-1 bg-zinc-800 rounded-full p-1">
                      <button className="p-1 rounded-full bg-purple-600 text-white">
                        <Moon size={14} />
                      </button>
                      <button className="p-1 rounded-full text-gray-400 hover:text-white">
                        <Sun size={14} />
                      </button>
                      <button className="p-1 rounded-full text-gray-400 hover:text-white">
                        <Monitor size={14} />
                      </button>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-300 mb-2">Notificaciones</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3 p-2 rounded-md hover:bg-zinc-800 transition-colors">
                      <Bell size={18} className="text-gray-400" />
                      <div className="flex-1">
                        <p className="text-sm text-gray-300">Notificaciones</p>
                        <p className="text-xs text-gray-500">Recibe alertas de nuevas funciones</p>
                      </div>
                      <div className="relative">
                        <input type="checkbox" className="sr-only" id="notifications" />
                        <label
                          htmlFor="notifications"
                          className="block w-10 h-6 rounded-full bg-zinc-700 cursor-pointer"
                        >
                          <span className="block w-4 h-4 mt-1 ml-1 bg-white rounded-full transition-transform duration-200 transform translate-x-0"></span>
                        </label>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-2 rounded-md hover:bg-zinc-800 transition-colors">
                      <Volume2 size={18} className="text-gray-400" />
                      <div className="flex-1">
                        <p className="text-sm text-gray-300">Sonidos</p>
                        <p className="text-xs text-gray-500">Sonidos al recibir mensajes</p>
                      </div>
                      <div className="relative">
                        <input type="checkbox" className="sr-only" id="sounds" />
                        <label htmlFor="sounds" className="block w-10 h-6 rounded-full bg-zinc-700 cursor-pointer">
                          <span className="block w-4 h-4 mt-1 ml-1 bg-white rounded-full transition-transform duration-200 transform translate-x-0"></span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-300 mb-2">Cuenta</h4>
                  <div className="space-y-1">
                    <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-zinc-800 transition-colors">
                      <User size={18} className="text-gray-400" />
                      <span className="text-sm text-gray-300">Perfil</span>
                    </button>
                    <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-zinc-800 transition-colors">
                      <Key size={18} className="text-gray-400" />
                      <span className="text-sm text-gray-300">Cambiar contraseña</span>
                    </button>
                    <button className="w-full flex items-center gap-3 p-2 text-left rounded-md hover:bg-zinc-800 transition-colors">
                      <Shield size={18} className="text-gray-400" />
                      <span className="text-sm text-gray-300">Privacidad</span>
                    </button>
                  </div>
                </div>

                <div className="pt-2 border-t border-white/10">
                  <p className="text-xs text-gray-500">
                    Qwark Beta v0.9.2 - Más opciones de personalización próximamente
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
