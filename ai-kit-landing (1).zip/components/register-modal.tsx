"use client"

import { useState } from "react"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface RegisterModalProps {
  isOpen: boolean
  onClose: () => void
  onRegister: (username: string, email: string, password: string) => void
}

export default function RegisterModal({ isOpen, onClose, onRegister }: RegisterModalProps) {
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [step, setStep] = useState(1)

  const validateStep1 = () => {
    if (!username.trim()) {
      setError("Por favor, ingresa un nombre de usuario")
      return false
    }
    if (!email.trim()) {
      setError("Por favor, ingresa un correo electrónico")
      return false
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      setError("Por favor, ingresa un correo electrónico válido")
      return false
    }
    setError("")
    return true
  }

  const validateStep2 = () => {
    if (!password) {
      setError("Por favor, ingresa una contraseña")
      return false
    }
    if (password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres")
      return false
    }
    if (password !== confirmPassword) {
      setError("Las contraseñas no coinciden")
      return false
    }
    setError("")
    return true
  }

  const handleNextStep = () => {
    if (validateStep1()) {
      setStep(2)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (validateStep2()) {
      onRegister(username, email, password)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="relative w-full max-w-md">
        {/* User Icon */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center z-10">
          <div className="text-gray-400 text-4xl">
            <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
              />
            </svg>
          </div>
        </div>

        {/* Close Button */}
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white z-10">
          <X size={20} />
        </button>

        {/* Form */}
        <form
          onSubmit={step === 1 ? handleNextStep : handleSubmit}
          className="flex flex-col items-center bg-zinc-900/90 border border-white/10 rounded-3xl pt-16 pb-8 px-6 shadow-xl"
        >
          <h2 className="text-xl font-bold text-white mb-6 mt-2">CREAR CUENTA</h2>

          {error && <p className="text-sm mb-4 text-red-500">{error}</p>}

          {step === 1 ? (
            <>
              <div className="relative w-full mb-6">
                <input
                  type="text"
                  placeholder="Nombre de usuario"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-transparent border-b border-zinc-700 py-2 pr-8 text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
                />
                <div className="absolute right-2 bottom-2 text-zinc-500">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                </div>
              </div>

              <div className="relative w-full mb-6">
                <input
                  type="email"
                  placeholder="Correo electrónico"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-transparent border-b border-zinc-700 py-2 pr-8 text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
                />
                <div className="absolute right-2 bottom-2 text-zinc-500">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    />
                  </svg>
                </div>
              </div>

              <Button
                type="button"
                onClick={handleNextStep}
                className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300 mt-6"
              >
                Siguiente
              </Button>
            </>
          ) : (
            <>
              <div className="relative w-full mb-6">
                <input
                  type="password"
                  placeholder="Contraseña"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-transparent border-b border-zinc-700 py-2 pr-8 text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
                />
                <div className="absolute right-2 bottom-2 text-zinc-500">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                    />
                  </svg>
                </div>
              </div>

              <div className="relative w-full mb-6">
                <input
                  type="password"
                  placeholder="Confirmar contraseña"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-transparent border-b border-zinc-700 py-2 pr-8 text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
                />
                <div className="absolute right-2 bottom-2 text-zinc-500">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                    />
                  </svg>
                </div>
              </div>

              <div className="flex w-full gap-4 mt-6">
                <Button
                  type="button"
                  onClick={() => setStep(1)}
                  className="w-1/2 bg-zinc-800 hover:bg-zinc-700 text-white"
                >
                  Atrás
                </Button>
                <Button
                  type="submit"
                  className="w-1/2 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300"
                >
                  Registrarse
                </Button>
              </div>
            </>
          )}

          <p className="text-zinc-600 mt-6">
            ¿Ya tienes una cuenta?{" "}
            <a href="#" className="text-zinc-400 hover:text-purple-400 transition-colors">
              Inicia sesión
            </a>
          </p>
        </form>
      </div>
    </div>
  )
}
