"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Plus, MessageSquare, Trash2 } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface ChatSidebarProps {
  onNewChat: () => void
  chats: { id: string; title: string; date: string }[]
  activeChat: string | null
  onSelectChat: (id: string) => void
  onDeleteChat: (id: string) => void
}

export default function ChatSidebar({ onNewChat, chats, activeChat, onSelectChat, onDeleteChat }: ChatSidebarProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      {/* Toggle button for mobile */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-20 left-2 z-30 bg-zinc-800 rounded-full p-2 text-white shadow-lg"
      >
        {isOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
      </button>

      {/* Sidebar */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ duration: 0.3 }}
            className="fixed top-16 left-0 bottom-0 w-64 bg-zinc-900 border-r border-white/10 z-20 md:relative md:top-0 md:block"
          >
            <div className="flex flex-col h-full">
              <div className="p-4 border-b border-white/10">
                <button
                  onClick={onNewChat}
                  className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white rounded-md py-2 px-4 transition-colors"
                >
                  <Plus size={16} />
                  <span>Nuevo chat</span>
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-2">
                <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">
                  Conversaciones recientes
                </h3>
                {chats.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 text-sm">
                    <MessageSquare className="mx-auto mb-2 opacity-50" size={24} />
                    <p>No hay conversaciones</p>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {chats.map((chat) => (
                      <div
                        key={chat.id}
                        className={`flex items-center justify-between rounded-md px-3 py-2 cursor-pointer group ${
                          activeChat === chat.id ? "bg-purple-600/20 text-white" : "text-gray-300 hover:bg-zinc-800"
                        }`}
                        onClick={() => onSelectChat(chat.id)}
                      >
                        <div className="flex items-center gap-2 overflow-hidden">
                          <MessageSquare size={16} />
                          <div className="truncate">
                            <div className="text-sm truncate">{chat.title}</div>
                            <div className="text-xs text-gray-500">{chat.date}</div>
                          </div>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            onDeleteChat(chat.id)
                          }}
                          className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-500 transition-opacity"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop sidebar toggle */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="hidden md:block fixed top-20 left-2 z-30 bg-zinc-800 rounded-full p-2 text-white shadow-lg"
      >
        {isOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
      </button>
    </>
  )
}
