"use client"

import { LogOut } from "lucide-react"

interface SimpleLogoutButtonProps {
  onLogout: () => void
  className?: string
}

export default function SimpleLogoutButton({ onLogout, className = "" }: SimpleLogoutButtonProps) {
  return (
    <button
      onClick={onLogout}
      className={`flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-gray-300 hover:text-white rounded-md transition-colors ${className}`}
    >
      <LogOut size={16} />
      <span className="text-sm">Cerrar sesión</span>
    </button>
  )
}
