"use client"

import { motion } from "framer-motion"
import { Star } from "lucide-react"

interface Testimonial {
  name: string
  role: string
  company: string
  image: string
  content: string
  stars: number
}

export default function Testimonials() {
  const testimonials: Testimonial[] = [
    {
      name: "Laura Martínez",
      role: "Diseñadora UX",
      company: "CreativeStudio",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "Qwark ha revolucionado mi flujo de trabajo. Me ayuda a generar ideas, refinar conceptos y resolver problemas de diseño. Es como tener un compañero de equipo disponible 24/7.",
      stars: 5,
    },
    {
      name: "Carlos Rodríguez",
      role: "Desarrollador Full-Stack",
      company: "TechSolutions",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "Como programador, Qwark me ha ahorrado incontables horas depurando código y buscando soluciones. Su capacidad para entender contexto técnico es impresionante.",
      stars: 5,
    },
    {
      name: "Elena Gómez",
      role: "Estudiante",
      company: "Universidad Autónoma",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "Uso Qwark para estudiar y preparar exámenes. Me explica conceptos complejos de forma sencilla y me ayuda a organizar mis apuntes. Ha mejorado mis calificaciones notablemente.",
      stars: 4,
    },
    {
      name: "Miguel Ángel",
      role: "Escritor",
      company: "Freelance",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "Qwark es mi asistente de escritura. Me ayuda con la investigación, me da ideas cuando tengo bloqueo creativo y revisa mi gramática. Es una herramienta indispensable.",
      stars: 5,
    },
  ]

  return (
    <div className="py-12">
      <h2 className="text-3xl font-bold text-center mb-8">
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
          Lo que dicen nuestros usuarios
        </span>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
        {testimonials.map((testimonial, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white/5 dark:bg-zinc-900/50 backdrop-blur-sm border border-white/10 rounded-xl p-6"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-full overflow-hidden">
                <img
                  src={testimonial.image || "/placeholder.svg"}
                  alt={testimonial.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h3 className="font-medium text-white">{testimonial.name}</h3>
                <p className="text-sm text-gray-400">
                  {testimonial.role}, {testimonial.company}
                </p>
              </div>
            </div>

            <p className="text-gray-300 mb-4">"{testimonial.content}"</p>

            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  size={16}
                  className={i < testimonial.stars ? "text-yellow-400 fill-yellow-400" : "text-gray-600"}
                />
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
