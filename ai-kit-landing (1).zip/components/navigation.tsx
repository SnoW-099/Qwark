"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Menu, X } from "lucide-react"
import ThemeToggleButton from "./theme-toggle-button"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 dark:bg-black/90 border-b border-gray-200 dark:border-white/10 backdrop-blur-sm">
      <div className="mx-auto px-4 max-w-7xl">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
            </div>
            <div className="flex items-center">
              <span className="text-gray-900 dark:text-white text-xl font-medium">Qwark</span>
              <div className="ml-2 px-1.5 py-0.5 bg-purple-600 rounded-md text-[10px] font-bold uppercase tracking-wider animate-pulse text-white">
                Beta
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <Link
              href="/"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm"
            >
              Inicio
            </Link>
            <Link
              href="/features"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm"
            >
              Características
            </Link>
            <Link
              href="/pricing"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm"
            >
              Precios
            </Link>
            <Link
              href="/updates"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm"
            >
              Actualizaciones
            </Link>
            <Link
              href="/credits"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm"
            >
              Créditos
            </Link>
            <div className="ml-4">
              <ThemeToggleButton />
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-4">
            <ThemeToggleButton />
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white p-1"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          className="md:hidden bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex flex-col py-4 px-4 space-y-3">
            <Link
              href="/"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Inicio
            </Link>
            <Link
              href="/features"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Características
            </Link>
            <Link
              href="/pricing"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Precios
            </Link>
            <Link
              href="/updates"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Actualizaciones
            </Link>
            <Link
              href="/credits"
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white py-2 transition-colors"
              onClick={() => setIsOpen(false)}
            >
              Créditos
            </Link>
          </div>
        </motion.div>
      )}
    </nav>
  )
}
