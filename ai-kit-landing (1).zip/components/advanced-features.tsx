"use client"

import { motion } from "framer-motion"
import { Calendar, BookOpen, Monitor, Pencil, Brain, Wand2, Sparkles } from "lucide-react"

interface Feature {
  icon: JSX.Element
  title: string
  description: string
  comingSoon?: boolean
}

export default function AdvancedFeatures() {
  const features: Feature[] = [
    {
      icon: <Calendar className="w-6 h-6 text-purple-400" />,
      title: "Organizador inteligente",
      description: "Planifica tu día, recibe recordatorios y optimiza tu tiempo con la ayuda de Qwark.",
      comingSoon: true,
    },
    {
      icon: <BookOpen className="w-6 h-6 text-purple-400" />,
      title: "Aprendizaje guiado",
      description: "Aprende nuevos temas con explicaciones personalizadas y quizzes automáticos.",
      comingSoon: true,
    },
    {
      icon: <Monitor className="w-6 h-6 text-purple-400" />,
      title: "Copiloto de escritorio",
      description: "Obtén ayuda instantánea mientras trabajas con cualquier aplicación.",
      comingSoon: true,
    },
    {
      icon: <Pencil className="w-6 h-6 text-purple-400" />,
      title: "Creador de contenido",
      description: "Genera ideas, mejora tus textos y adapta tu contenido a diferentes formatos.",
    },
    {
      icon: <Brain className="w-6 h-6 text-purple-400" />,
      title: "Memoria real",
      description: "Qwark recuerda tus preferencias y objetivos para ofrecerte ayuda personalizada.",
    },
    {
      icon: <Wand2 className="w-6 h-6 text-purple-400" />,
      title: "Modo creativo",
      description: "Potencia tu creatividad con ideas para historias, música, diseño y más.",
    },
    {
      icon: <Sparkles className="w-6 h-6 text-purple-400" />,
      title: "Funciones premium",
      description: "Accede a generación de imágenes, edición de video y asistentes automatizados.",
      comingSoon: true,
    },
  ]

  return (
    <div className="py-12">
      <h2 className="text-3xl font-bold text-center mb-2">
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
          Funciones avanzadas
        </span>
      </h2>
      <p className="text-gray-400 text-center mb-10 max-w-2xl mx-auto">
        Descubre todo lo que Qwark puede hacer por ti, desde tareas cotidianas hasta proyectos creativos complejos
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white/5 dark:bg-zinc-900/50 backdrop-blur-sm border border-white/10 rounded-xl p-6 relative"
          >
            {feature.comingSoon && (
              <div className="absolute top-3 right-3 px-2 py-1 bg-purple-600/20 border border-purple-500/30 rounded text-xs text-purple-300">
                Próximamente
              </div>
            )}
            <div className="w-12 h-12 rounded-full bg-purple-600/20 flex items-center justify-center mb-4">
              {feature.icon}
            </div>
            <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
            <p className="text-gray-400">{feature.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
