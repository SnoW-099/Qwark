"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Check, X, AlertCircle } from "lucide-react"
import Navigation from "@/components/navigation"

export default function PricingPage() {
  const plans = [
    {
      name: "Gratuito",
      price: "0€",
      description: "Para usuarios ocasionales",
      features: [
        { name: "Acceso básico a Qwark", included: true },
        { name: "Límite de 20 mensajes por día", included: true },
        { name: "Respuestas de texto", included: true },
        { name: "Soporte comunitario", included: true },
        { name: "Generación de imágenes", included: false },
        { name: "Asistencia con código", included: false },
        { name: "Procesamiento de documentos", included: false },
        { name: "Acceso prioritario", included: false },
      ],
      cta: "Comenzar gratis",
      popular: false,
    },
    {
      name: "Premium",
      price: "Próximamente",
      period: "",
      description: "Para uso personal avanzado",
      features: [
        { name: "Todo lo del plan Gratuito", included: true },
        { name: "Mensajes ilimitados", included: true },
        { name: "Respuestas más rápidas", included: true },
        { name: "Generación de imágenes (5/día)", included: true },
        { name: "Asistencia con código", included: true },
        { name: "Procesamiento de documentos", included: true },
        { name: "Soporte por email", included: true },
        { name: "Acceso prioritario", included: false },
      ],
      cta: "Unirse a la lista de espera",
      popular: true,
    },
    {
      name: "Pro",
      price: "Próximamente",
      period: "",
      description: "Para profesionales y equipos",
      features: [
        { name: "Todo lo del plan Premium", included: true },
        { name: "Generación de imágenes ilimitada", included: true },
        { name: "Análisis de video", included: true },
        { name: "Sistemas de pensamiento avanzados", included: true },
        { name: "Interacción por voz", included: true },
        { name: "Acceso prioritario", included: true },
        { name: "Soporte prioritario 24/7", included: true },
        { name: "API para desarrolladores", included: true },
      ],
      cta: "Contactar ventas",
      popular: false,
    },
  ]

  return (
    <div className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white">
      <Navigation />

      <div className="pt-24 pb-16 px-4 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
              Planes y precios
            </span>
          </h1>
          <p className="text-lg text-gray-700 dark:text-gray-400 max-w-2xl mx-auto">
            Elige el plan que mejor se adapte a tus necesidades
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800/30 rounded-lg p-4 mb-12 max-w-3xl mx-auto"
        >
          <div className="flex items-start gap-3">
            <AlertCircle className="text-purple-600 dark:text-purple-400 mt-1 flex-shrink-0" size={20} />
            <div>
              <h3 className="font-medium text-gray-900 dark:text-white mb-1">Gratis durante la fase Beta</h3>
              <p className="text-gray-700 dark:text-gray-300 text-sm">
                Qwark es completamente gratuito durante la fase Beta. Los planes de pago estarán disponibles una vez que
                la plataforma esté completamente desarrollada. ¡Disfruta de todas las funciones sin costo por ahora!
              </p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
              className={`bg-white dark:bg-zinc-900/50 border ${
                plan.popular ? "border-purple-500 dark:border-purple-500/50" : "border-gray-200 dark:border-white/10"
              } rounded-xl overflow-hidden relative shadow-md dark:shadow-none hover:shadow-lg transition-all duration-300`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0 bg-gradient-to-r from-purple-600 to-purple-800 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                  Popular
                </div>
              )}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{plan.name}</h3>
                <div className="flex items-end gap-1 mb-1">
                  <span className="text-3xl font-bold text-gray-900 dark:text-white">{plan.price}</span>
                  {plan.period && <span className="text-gray-600 dark:text-gray-400 mb-1">{plan.period}</span>}
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-6">{plan.description}</p>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature.name} className="flex items-start gap-2">
                      {feature.included ? (
                        <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      ) : (
                        <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                      )}
                      <span className={feature.included ? "text-gray-700 dark:text-gray-300" : "text-gray-500"}>
                        {feature.name}
                      </span>
                    </li>
                  ))}
                </ul>

                <Link
                  href="/"
                  className={`block w-full text-center py-2 px-4 rounded-md transition-colors ${
                    plan.popular
                      ? "bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
                      : "bg-gray-100 dark:bg-zinc-800 hover:bg-gray-200 dark:hover:bg-zinc-700 text-gray-900 dark:text-white"
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="mt-16 bg-white dark:bg-zinc-900/50 border border-gray-200 dark:border-white/10 rounded-xl p-8 text-center max-w-3xl mx-auto shadow-md dark:shadow-none"
        >
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">¿Necesitas un plan personalizado?</h2>
          <p className="text-gray-700 dark:text-gray-400 mb-6">
            Si tienes necesidades específicas o requieres un plan para tu empresa, contáctanos para obtener una solución
            personalizada.
          </p>
          <Link
            href="/contact"
            className="inline-block bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white rounded-md px-6 py-3 shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300"
          >
            Contactar con ventas
          </Link>
        </motion.div>
      </div>
    </div>
  )
}
