"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import AuthSystem from "@/components/auth-system"
import LoadingScreen from "@/components/loading-screen"
import Navigation from "@/components/navigation"
import ChatInterface from "@/components/chat-interface"
import FAQSection from "@/components/faq-section"
import AIComparison from "@/components/ai-comparison"
import AdvancedFeatures from "@/components/advanced-features"
import InteractiveDemo from "@/components/interactive-demo"
import { Sparkles, Zap, MessageSquare, ArrowRight, Rocket, Brain, Shield } from "lucide-react"

// Número máximo de mensajes para usuarios no registrados
const MAX_GUEST_MESSAGES = 10

export default function Home() {
  const [showChat, setShowChat] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [authMode, setAuthMode] = useState<"login" | "register">("login")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [guestMessageCount, setGuestMessageCount] = useState(0)

  // Verificar si hay una sesión guardada al cargar la página
  useEffect(() => {
    const savedUser = localStorage.getItem("qwark_user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      setIsLoggedIn(true)
      setUsername(userData.username)
    }
  }, [])

  const handleStartChat = () => {
    if (!isLoggedIn) {
      setAuthMode("login")
      setShowAuthModal(true)
    } else {
      setIsLoading(true)
      setTimeout(() => {
        setShowChat(true)
        setIsLoading(false)
      }, 1500)
    }
  }

  const handleTryDemo = () => {
    if (guestMessageCount >= MAX_GUEST_MESSAGES) {
      setAuthMode("register")
      setShowAuthModal(true)
    } else {
      setIsLoading(true)
      setTimeout(() => {
        setShowChat(true)
        setIsLoading(false)
      }, 1500)
    }
  }

  const handleLogin = (username, password) => {
    // Simulate login process
    console.log("Logging in with:", username, password)

    // For demo purposes, we'll just accept any login
    setIsLoggedIn(true)
    setUsername(username)
    setShowAuthModal(false)

    // Guardar la sesión en localStorage
    localStorage.setItem("qwark_user", JSON.stringify({ username }))

    // Mostrar el chat después de iniciar sesión
    setIsLoading(true)
    setTimeout(() => {
      setShowChat(true)
      setIsLoading(false)
    }, 1500)
  }

  const handleRegister = (username, email, password) => {
    // Simulate registration process
    console.log("Registering with:", username, email, password)

    // For demo purposes, we'll just accept any registration
    setIsLoggedIn(true)
    setUsername(username)
    setShowAuthModal(false)

    // Guardar la sesión en localStorage
    localStorage.setItem("qwark_user", JSON.stringify({ username }))

    // Mostrar el chat después de registrarse
    setIsLoading(true)
    setTimeout(() => {
      setShowChat(true)
      setIsLoading(false)
    }, 1500)
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setUsername("")
    localStorage.removeItem("qwark_user")
    setShowChat(false)
  }

  const handleCloseChat = () => {
    setShowChat(false)
    // Si no está logueado, incrementar el contador de mensajes de invitado
    if (!isLoggedIn) {
      setGuestMessageCount((prev) => prev + 1)
    }
  }

  if (isLoading) {
    return <LoadingScreen onLoadingComplete={() => setIsLoading(false)} />
  }

  return (
    <div className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white overflow-hidden">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute top-0 left-1/4 w-1/2 h-1/2 bg-purple-600/5 dark:bg-purple-600/10 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "8s" }}
        ></div>
        <div
          className="absolute bottom-0 right-1/4 w-1/3 h-1/3 bg-purple-800/5 dark:bg-purple-800/10 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "12s" }}
        ></div>
        <div
          className="absolute top-1/3 right-1/4 w-1/4 h-1/4 bg-purple-400/3 dark:bg-purple-400/5 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "10s" }}
        ></div>
      </div>

      {/* Auth Modal */}
      <AuthSystem
        isOpen={showAuthModal}
        initialMode={authMode}
        onClose={() => setShowAuthModal(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      {/* Navigation */}
      <Navigation />

      {showChat ? (
        // Chat Interface (Full Screen)
        <ChatInterface
          username={username || "Invitado"}
          onLogout={handleLogout}
          onClose={handleCloseChat}
          isGuest={!isLoggedIn}
          guestMessageCount={guestMessageCount}
          maxGuestMessages={MAX_GUEST_MESSAGES}
        />
      ) : (
        // Landing Page
        <div className="pt-16">
          {/* Hero Section */}
          <section className="py-16 md:py-24">
            <div className="container mx-auto px-4">
              <div className="flex flex-col lg:flex-row items-center">
                <motion.div
                  className="w-full lg:w-1/2 lg:pr-12 mb-12 lg:mb-0"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                  >
                    <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
                      Tu asistente de IA{" "}
                      <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
                        personal e intuitivo
                      </span>
                    </h1>
                    <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 mb-8">
                      Conversaciones naturales, respuestas precisas y una experiencia que se adapta a ti. Descubre una
                      nueva forma de interactuar con la tecnología.
                    </p>
                  </motion.div>

                  <motion.div
                    className="flex flex-col sm:flex-row gap-4 mb-8"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                  >
                    {isLoggedIn ? (
                      <Button
                        className="flex-1 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300 transform hover:scale-[1.02] text-base py-6"
                        onClick={handleStartChat}
                      >
                        <span className="flex items-center gap-2">
                          Continuar conversación <Rocket size={18} />
                        </span>
                      </Button>
                    ) : (
                      <>
                        <Button
                          className="flex-1 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300 transform hover:scale-[1.02] text-base py-6"
                          onClick={() => {
                            setAuthMode("register")
                            setShowAuthModal(true)
                          }}
                        >
                          <span className="flex items-center gap-2">
                            Crear cuenta gratis <Rocket size={18} />
                          </span>
                        </Button>
                        <Button
                          className="flex-1 bg-white dark:bg-zinc-800 hover:bg-gray-100 dark:hover:bg-zinc-700 text-gray-900 dark:text-white border border-gray-300 dark:border-zinc-700 transition-all duration-300 text-base py-6"
                          onClick={handleTryDemo}
                        >
                          <span className="flex items-center gap-2">
                            Probar sin registro <ArrowRight size={18} />
                          </span>
                        </Button>
                      </>
                    )}
                  </motion.div>

                  <motion.div
                    className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.5 }}
                  >
                    <div className="flex items-center gap-1">
                      <Shield size={16} />
                      <span>Privacidad garantizada</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Sparkles size={16} />
                      <span>Actualizado constantemente</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Brain size={16} />
                      <span>IA avanzada</span>
                    </div>
                  </motion.div>
                </motion.div>

                <motion.div
                  className="w-full lg:w-1/2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="relative">
                    <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-purple-800 opacity-20 blur-xl rounded-2xl"></div>
                    <InteractiveDemo />
                  </div>
                </motion.div>
              </div>
            </div>
          </section>

          {/* Features Section */}
          <section className="py-16 bg-gray-50 dark:bg-zinc-950/50">
            <div className="container mx-auto px-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center mb-16"
              >
                <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
                    ¿Por qué elegir Qwark?
                  </span>
                </h2>
                <p className="text-lg text-gray-700 dark:text-gray-400 max-w-2xl mx-auto">
                  Diseñado para ofrecerte una experiencia única, personalizada y adaptada a tus necesidades
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  className="bg-white dark:bg-zinc-900/50 rounded-xl p-6 shadow-md dark:shadow-none dark:border dark:border-white/5"
                >
                  <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center mb-4">
                    <MessageSquare className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Conversaciones naturales</h3>
                  <p className="text-gray-700 dark:text-gray-400">
                    Habla con Qwark como lo harías con un amigo. Entiende el contexto y mantiene conversaciones fluidas.
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="bg-white dark:bg-zinc-900/50 rounded-xl p-6 shadow-md dark:shadow-none dark:border dark:border-white/5"
                >
                  <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center mb-4">
                    <Sparkles className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Respuestas precisas</h3>
                  <p className="text-gray-700 dark:text-gray-400">
                    Obtén información actualizada y relevante para tus preguntas, sin rodeos ni contenido innecesario.
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="bg-white dark:bg-zinc-900/50 rounded-xl p-6 shadow-md dark:shadow-none dark:border dark:border-white/5"
                >
                  <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center mb-4">
                    <Zap className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Personalización</h3>
                  <p className="text-gray-700 dark:text-gray-400">
                    Qwark aprende de tus interacciones y se adapta a tus preferencias para ofrecerte una experiencia
                    única.
                  </p>
                </motion.div>
              </div>
            </div>
          </section>

          {/* Advanced Features Section */}
          <section className="py-16">
            <div className="container mx-auto px-4">
              <AdvancedFeatures />
            </div>
          </section>

          {/* AI Comparison Section */}
          <section className="py-16 bg-gray-50 dark:bg-zinc-950/50">
            <div className="container mx-auto px-4">
              <AIComparison />
            </div>
          </section>

          {/* FAQ Section */}
          <section className="py-16">
            <div className="container mx-auto px-4">
              <FAQSection />
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-16 bg-gray-50 dark:bg-zinc-950/50">
            <div className="container mx-auto px-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="max-w-4xl mx-auto bg-gradient-to-r from-purple-600/10 to-purple-800/10 dark:from-purple-600/20 dark:to-purple-800/20 backdrop-blur-sm border border-purple-500/20 rounded-2xl p-8 md:p-12 text-center"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
                  ¿Listo para descubrir el poder de Qwark?
                </h2>
                <p className="text-lg text-gray-700 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
                  Únete a la comunidad de usuarios que ya están aprovechando las capacidades de nuestro asistente de IA
                  para mejorar su productividad y creatividad.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  {isLoggedIn ? (
                    <Button
                      className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300 transform hover:scale-[1.02] text-base py-6 px-8"
                      onClick={handleStartChat}
                    >
                      <span className="flex items-center gap-2">
                        Continuar conversación <ArrowRight size={18} />
                      </span>
                    </Button>
                  ) : (
                    <>
                      <Button
                        className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300 transform hover:scale-[1.02] text-base py-6 px-8"
                        onClick={() => {
                          setAuthMode("register")
                          setShowAuthModal(true)
                        }}
                      >
                        <span className="flex items-center gap-2">
                          Crear cuenta gratuita <ArrowRight size={18} />
                        </span>
                      </Button>
                      <Button
                        className="bg-white dark:bg-zinc-800 hover:bg-gray-100 dark:hover:bg-zinc-700 text-gray-900 dark:text-white border border-gray-300 dark:border-zinc-700 transition-all duration-300 text-base py-6 px-8"
                        onClick={() => {
                          setAuthMode("login")
                          setShowAuthModal(true)
                        }}
                      >
                        <span className="flex items-center gap-2">
                          Iniciar sesión <ArrowRight size={18} />
                        </span>
                      </Button>
                    </>
                  )}
                </div>
              </motion.div>
            </div>
          </section>

          {/* Footer */}
          <footer className="bg-white dark:bg-black border-t border-gray-200 dark:border-white/10 py-8">
            <div className="container mx-auto px-4">
              <div className="flex flex-col md:flex-row justify-between items-center">
                <div className="flex items-center gap-2 mb-4 md:mb-0">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                  </div>
                  <span className="text-gray-900 dark:text-white text-lg font-medium">Qwark</span>
                  <div className="ml-1 px-1.5 py-0.5 bg-purple-600 rounded-md text-[10px] font-bold uppercase tracking-wider text-white">
                    Beta
                  </div>
                </div>

                <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm mb-4 md:mb-0">
                  <Link
                    href="/"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                  >
                    Inicio
                  </Link>
                  <Link
                    href="/features"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                  >
                    Características
                  </Link>
                  <Link
                    href="/pricing"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                  >
                    Precios
                  </Link>
                  <Link
                    href="/updates"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                  >
                    Actualizaciones
                  </Link>
                  <Link
                    href="/credits"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                  >
                    Créditos
                  </Link>
                </div>

                <div className="flex flex-wrap justify-center gap-x-4 gap-y-2 text-xs">
                  <Link
                    href="/terms"
                    className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                  >
                    Términos
                  </Link>
                  <Link
                    href="/privacy"
                    className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                  >
                    Privacidad
                  </Link>
                  <Link
                    href="/cookies"
                    className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                  >
                    Cookies
                  </Link>
                </div>
              </div>
              <div className="mt-6 text-center text-xs text-gray-500">
                © {new Date().getFullYear()} Qwark. Todos los derechos reservados.
              </div>
            </div>
          </footer>
        </div>
      )}
    </div>
  )
}
