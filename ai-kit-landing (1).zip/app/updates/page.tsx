"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Calendar, Code, ImageIcon, MessageSquare, Video, Zap } from "lucide-react"
import Navigation from "@/components/navigation"

export default function UpdatesPage() {
  const updates = [
    {
      version: "0.9.2",
      date: "11 de Abril, 2023",
      title: "Mejoras en la interfaz y rendimiento",
      description:
        "Hemos realizado mejoras significativas en la interfaz de usuario y optimizado el rendimiento general de la plataforma.",
      changes: [
        "Rediseño completo de la interfaz de usuario",
        "Mejoras en la velocidad de respuesta",
        "Corrección de errores menores",
        "Optimización del consumo de recursos",
      ],
      icon: <Zap className="w-6 h-6 text-purple-400" />,
    },
    {
      version: "0.9.1",
      date: "28 de Marzo, 2023",
      title: "Soporte para conversaciones más naturales",
      description: "Hemos mejorado el modelo de lenguaje para permitir conversaciones más naturales y fluidas.",
      changes: [
        "Mejora en la comprensión del contexto",
        "Respuestas más coherentes y naturales",
        "Soporte para conversaciones largas",
        "Mejor manejo de preguntas complejas",
      ],
      icon: <MessageSquare className="w-6 h-6 text-purple-400" />,
    },
    {
      version: "0.9.0",
      date: "15 de Marzo, 2023",
      title: "Lanzamiento de la versión Beta",
      description: "Primera versión beta pública de Qwark, con funcionalidades básicas de chat y asistencia.",
      changes: [
        "Interfaz de chat básica",
        "Modelo de lenguaje inicial",
        "Sistema de cuentas de usuario",
        "Soporte para preguntas y respuestas simples",
      ],
      icon: <Calendar className="w-6 h-6 text-purple-400" />,
    },
  ]

  const upcoming = [
    {
      title: "Generación de imágenes",
      description: "Próximamente podrás generar imágenes a partir de descripciones textuales.",
      eta: "Mayo 2023",
      icon: <ImageIcon className="w-6 h-6 text-purple-400" />,
    },
    {
      title: "Generación de código",
      description: "Asistencia avanzada para programadores con generación y explicación de código.",
      eta: "Junio 2023",
      icon: <Code className="w-6 h-6 text-purple-400" />,
    },
    {
      title: "Procesamiento de video",
      description: "Capacidad para analizar y generar contenido basado en videos.",
      eta: "Julio 2023",
      icon: <Video className="w-6 h-6 text-purple-400" />,
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />

      <div className="pt-24 pb-16 px-4 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
              Actualizaciones y novedades
            </span>
          </h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Mantente al día con las últimas mejoras y próximas funcionalidades de Qwark
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Calendar className="mr-2" /> Historial de actualizaciones
            </h2>

            <div className="space-y-8">
              {updates.map((update, index) => (
                <motion.div
                  key={update.version}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-zinc-900/50 border border-white/10 rounded-xl p-6"
                >
                  <div className="flex items-start gap-4">
                    <div className="mt-1">{update.icon}</div>
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold text-white">{update.title}</h3>
                        <span className="px-2 py-1 bg-purple-600/20 border border-purple-500/30 rounded text-xs text-purple-300">
                          v{update.version}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 mb-3">{update.date}</p>
                      <p className="text-gray-400 mb-4">{update.description}</p>

                      <h4 className="text-sm font-semibold text-gray-300 mb-2">Cambios principales:</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-400 space-y-1">
                        {update.changes.map((change, i) => (
                          <li key={i}>{change}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Zap className="mr-2" /> Próximamente
            </h2>

            <div className="space-y-6">
              {upcoming.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                  className="bg-zinc-900/50 border border-white/10 rounded-xl p-5"
                >
                  <div className="flex items-start gap-4">
                    <div className="mt-1">{feature.icon}</div>
                    <div>
                      <h3 className="text-lg font-bold text-white mb-1">{feature.title}</h3>
                      <p className="text-gray-400 text-sm mb-2">{feature.description}</p>
                      <div className="flex items-center">
                        <span className="text-xs text-purple-400">Estimado: {feature.eta}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
                className="mt-8 p-5 border border-purple-500/30 rounded-xl bg-purple-500/5"
              >
                <h3 className="text-lg font-bold text-white mb-3">¿Qué te gustaría ver?</h3>
                <p className="text-gray-400 text-sm mb-4">
                  Estamos constantemente mejorando Qwark. Nos encantaría saber qué funcionalidades te gustaría ver en
                  futuras actualizaciones.
                </p>
                <Link
                  href="/feedback"
                  className="inline-block bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white rounded-md px-4 py-2 text-sm shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300"
                >
                  Enviar sugerencia
                </Link>
              </motion.div>
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="text-center"
        >
          <Link
            href="/"
            className="inline-block bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white rounded-md px-6 py-3 shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300"
          >
            Volver al inicio
          </Link>
        </motion.div>
      </div>
    </div>
  )
}
