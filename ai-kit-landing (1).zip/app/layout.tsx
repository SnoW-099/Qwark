import "./globals.css"
import { ThemeProvider } from "@/contexts/theme-context"
import ScrollToTop from "@/components/scroll-to-top"
import FeedbackForm from "@/components/feedback-form"

export const metadata = {
  title: "Qwark - Tu asistente personal de IA",
  description:
    "Qwark es un asistente de IA conversacional que aprende de tus interacciones para ofrecerte respuestas personalizadas y relevantes.",
  keywords: "IA, inteligencia artificial, asistente virtual, chatbot, Qwark, IA conversacional",
  openGraph: {
    title: "Qwark - Tu asistente personal de IA",
    description:
      "Qwark es un asistente de IA conversacional que aprende de tus interacciones para ofrecerte respuestas personalizadas y relevantes.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Qwark - Tu asistente personal de IA",
      },
    ],
  },
    generator: 'v0.dev'
}

export default function RootLayout({ children }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className="bg-white dark:bg-black text-gray-900 dark:text-white">
        <ThemeProvider>
          {children}
          <ScrollToTop />
          <FeedbackForm />
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'