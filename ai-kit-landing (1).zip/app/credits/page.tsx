"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Github, Twitter, Linkedin, Mail } from "lucide-react"
import Navigation from "@/components/navigation"

export default function CreditsPage() {
  const developers = [
    {
      name: "Snow",
      role: "Desarrollador Principal",
      image: "/placeholder.svg?height=200&width=200",
      emoji: "❄️",
      bio: "Apasionado por la inteligencia artificial y el desarrollo web. Creador principal de Qwark.",
      links: {
        github: "https://github.com/snow",
        twitter: "https://twitter.com/snow",
        linkedin: "https://linkedin.com/in/snow",
        email: "snow@qwark.ai",
      },
    },
    {
      name: "lil_culiculi",
      role: "Colaborador",
      image: "/placeholder.svg?height=200&width=200",
      emoji: "🎨",
      bio: "Especialista en diseño de interfaces y experiencia de usuario. Contribuye con ideas creativas para Qwark.",
      links: {
        github: "https://github.com/lil_culiculi",
        twitter: "https://twitter.com/lil_culiculi",
        linkedin: "https://linkedin.com/in/lil_culiculi",
        email: "lil_culiculi@qwark.ai",
      },
    },
    {
      name: "simbopolo",
      role: "Colaborador",
      image: "/placeholder.svg?height=200&width=200",
      emoji: "🧠",
      bio: "Experto en modelos de lenguaje y procesamiento de lenguaje natural. Ayuda a mejorar las capacidades de Qwark.",
      links: {
        github: "https://github.com/simbopolo",
        twitter: "https://twitter.com/simbopolo",
        linkedin: "https://linkedin.com/in/simbopolo",
        email: "simbopolo@qwark.ai",
      },
    },
  ]

  return (
    <div className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white">
      <Navigation />

      <div className="pt-24 pb-16 px-4 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
              El equipo detrás de Qwark
            </span>
          </h1>
          <p className="text-lg text-gray-700 dark:text-gray-400 max-w-2xl mx-auto">
            Conoce a las personas que han hecho posible esta plataforma de IA conversacional
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {developers.map((dev, index) => (
            <motion.div
              key={dev.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white dark:bg-zinc-900/50 border border-gray-200 dark:border-white/10 rounded-xl overflow-hidden shadow-md dark:shadow-none hover:shadow-lg dark:hover:border-purple-500/20 transition-all duration-300"
            >
              <div className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center overflow-hidden text-3xl">
                    {dev.emoji}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">{dev.name}</h3>
                    <p className="text-purple-600 dark:text-purple-400">{dev.role}</p>
                  </div>
                </div>

                <p className="text-gray-700 dark:text-gray-300 mb-4 text-sm">{dev.bio}</p>

                <div className="flex gap-4">
                  <a
                    href={dev.links.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                    aria-label="GitHub"
                  >
                    <Github size={20} />
                  </a>
                  <a
                    href={dev.links.twitter}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                    aria-label="Twitter"
                  >
                    <Twitter size={20} />
                  </a>
                  <a
                    href={dev.links.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                    aria-label="LinkedIn"
                  >
                    <Linkedin size={20} />
                  </a>
                  <a
                    href={`mailto:${dev.links.email}`}
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                    aria-label="Email"
                  >
                    <Mail size={20} />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <Link
            href="/"
            className="inline-block bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white rounded-md px-6 py-3 shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300"
          >
            Volver al inicio
          </Link>
        </motion.div>
      </div>
    </div>
  )
}
