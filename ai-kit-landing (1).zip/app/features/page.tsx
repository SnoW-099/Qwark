"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Navigation from "@/components/navigation"
import {
  MessageSquare,
  Sparkles,
  Zap,
  Code,
  ImageIcon,
  Video,
  Lightbulb,
  Globe,
  Lock,
  Cpu,
  FileText,
  Headphones,
} from "lucide-react"

export default function FeaturesPage() {
  const features = [
    {
      icon: <MessageSquare className="w-6 h-6 text-purple-400" />,
      title: "Conversaciones naturales",
      description:
        "Mantén conversaciones fluidas y naturales con Qwark. Entiende el contexto y mantiene la coherencia a lo largo de toda la conversación.",
    },
    {
      icon: <Sparkles className="w-6 h-6 text-purple-400" />,
      title: "Respuestas precisas",
      description:
        "Obtén respuestas precisas y relevantes a tus preguntas, basadas en información actualizada y verificada.",
    },
    {
      icon: <Zap className="w-6 h-6 text-purple-400" />,
      title: "Personalización",
      description:
        "Qwark aprende de tus interacciones y se adapta a tus preferencias para ofrecerte una experiencia personalizada.",
    },
    {
      icon: <Code className="w-6 h-6 text-purple-400" />,
      title: "Asistencia con código",
      description:
        "Recibe ayuda con tu código, desde explicaciones de conceptos hasta depuración y optimización de algoritmos.",
      comingSoon: true,
    },
    {
      icon: <ImageIcon className="w-6 h-6 text-purple-400" />,
      title: "Generación de imágenes",
      description: "Crea imágenes a partir de descripciones textuales, desde ilustraciones hasta diseños realistas.",
      comingSoon: true,
    },
    {
      icon: <Video className="w-6 h-6 text-purple-400" />,
      title: "Análisis de video",
      description: "Analiza y genera contenido basado en videos, incluyendo resúmenes, transcripciones y más.",
      comingSoon: true,
    },
    {
      icon: <Lightbulb className="w-6 h-6 text-purple-400" />,
      title: "Creatividad mejorada",
      description: "Potencia tu creatividad con sugerencias, ideas y contenido original generado por Qwark.",
    },
    {
      icon: <Globe className="w-6 h-6 text-purple-400" />,
      title: "Soporte multilingüe",
      description: "Comunícate con Qwark en múltiples idiomas y obtén traducciones precisas y naturales.",
    },
    {
      icon: <Lock className="w-6 h-6 text-purple-400" />,
      title: "Privacidad y seguridad",
      description: "Tus conversaciones y datos están protegidos con las más altas medidas de seguridad y privacidad.",
    },
    {
      icon: <Cpu className="w-6 h-6 text-purple-400" />,
      title: "Sistemas de pensamiento",
      description: "Algoritmos avanzados que permiten a Qwark razonar, analizar y resolver problemas complejos.",
      comingSoon: true,
    },
    {
      icon: <FileText className="w-6 h-6 text-purple-400" />,
      title: "Procesamiento de documentos",
      description: "Analiza, resume y extrae información relevante de documentos largos y complejos.",
    },
    {
      icon: <Headphones className="w-6 h-6 text-purple-400" />,
      title: "Interacción por voz",
      description: "Interactúa con Qwark mediante comandos de voz y recibe respuestas en formato de audio.",
      comingSoon: true,
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />

      <div className="pt-24 pb-16 px-4 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-600">
              Características de Qwark
            </span>
          </h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Descubre todas las capacidades de nuestro asistente de IA y cómo puede ayudarte en tu día a día
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-zinc-900/50 border border-white/10 rounded-xl p-6 relative overflow-hidden"
            >
              {feature.comingSoon && (
                <div className="absolute top-3 right-3 px-2 py-1 bg-purple-600/20 border border-purple-500/30 rounded text-xs text-purple-300">
                  Próximamente
                </div>
              )}
              <div className="flex items-start gap-4 mb-4">
                <div className="mt-1">{feature.icon}</div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <Link
            href="/pricing"
            className="inline-block bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white rounded-md px-6 py-3 shadow-lg shadow-purple-900/20 hover:shadow-purple-800/30 transition-all duration-300"
          >
            Ver planes y precios
          </Link>
        </motion.div>
      </div>
    </div>
  )
}
